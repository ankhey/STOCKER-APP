# Sausage Stock Manager — Level 1

React + TypeScript + Vite PWA on Supabase (Postgres, Auth, RLS). Level 1 covers products, suppliers, supplier
schedules, multi-row stock receiving, a batch ledger, a dashboard and an installable offline-shell PWA.

**Status honesty.** This code was written without network access, so it has NOT been installed, built, or run against a
real Supabase project by its author. See "What has and has not been verified" below. Expect to fix small compile or SQL
errors on first run.

## 1. Supabase setup
1. Create a project at supabase.com.
2. SQL Editor: run `supabase/migrations/0001…0006` in order (or `supabase db push`).
3. Authentication > Users > Add user: your owner email and password. Then, under Providers > Email, disable public sign-ups.
4. Project Settings > API: copy the Project URL and the **anon/publishable** key. Never use the service-role key in this app.

## 2. Run locally
```bash
cp .env.example .env     # fill in VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY
npm install
npm run dev              # http://localhost:5173
```
Sign in, name your shop (first sign-in makes you owner), then Settings: set the **timezone** (expiry status depends on it)
and optionally "Seed 3 starter suppliers".

## 3. Test and build
```bash
npm test                 # vitest unit tests
npm run build            # type-check + production build (also generates manifest and service worker)
npm run check:pwa        # asserts manifest fields, icons, service worker, app-shell precache
npm run verify           # build + check:pwa + test
```
Optional database check: edit and run `supabase/tests/receive_delivery_check.sql` in the SQL editor (rolls back).

## 4. Deploy to Netlify
`netlify.toml` is included (build command, `dist` publish folder, single-page-app redirect, no-cache headers for the service worker,
and a Permissions-Policy that allows the camera for scanning).

**Recommended (Git-based):**
1. Run `npm run verify` locally first. The build type-checks, so any compile error will fail the Netlify deploy (a failed deploy never goes live).
2. Push the project to a GitHub/GitLab repo (`.env` and `.netlify` are git-ignored).
3. Netlify > Add new project > Import from Git > pick the repo. Settings are read from `netlify.toml`.
4. Site configuration > Environment variables: add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` (anon/publishable key only), then trigger a deploy.
5. Supabase > Authentication > URL Configuration: set Site URL to your `https://<name>.netlify.app` address and add it to Redirect URLs.
6. Open the URL on your phone, sign in, then install it (section 5).

**Manual alternative:** `npm run build`, then `netlify deploy --dir=dist --prod` (manual deploys do not run a build).
If the site is also connected to Git, the next push replaces a manual deploy.

Any other static host with an HTTPS URL and a single-page-app fallback also works.

## 5. Install on Android
Open the **HTTPS** deployed URL in Chrome > menu > "Install app" / "Add to Home screen". (`localhost` installs only on the
same machine; test on a phone via the deployed URL.) After one online visit the app shell opens offline.

## 6. How saving works (local vs confirmed)
- The receiving form is auto-saved as a **draft on this device**. A draft is not a delivery.
- "Confirm and save" calls the database function `receive_delivery`: delivery + batches + receipt movements in one transaction.
  The screen says "Confirmed by the database" only after the database answers.
- If you are offline or the connection fails, the delivery goes to an **on-device outbox**, shown with a "NOT confirmed"
  warning and a banner on every page. Press **Retry sending now** to send. Each delivery has one idempotency key, so a retry
  after a timeout can never create a second receipt.
- Product lookup works offline from a copy of the product list saved on this device (may be out of date).
- Private database responses are never stored by the service worker.
- Holding a batch needs a reason and blocks sale eligibility. Discarding needs a reason, records the remaining packets as wastage in one transaction, and cannot be undone. Both are logged.

## 6b. Barcode scanning
A **Scan** button appears next to the product code/barcode field on Receive Stock rows, on the product form's barcode field,
and on the Products and Batch Ledger search boxes. It uses the phone's rear camera, entirely on the device.
- Chrome on Android uses the built-in `BarcodeDetector`; other browsers load the ZXing decoder on demand (first use needs a connection unless cached).
- Retail numbers (EAN-8, UPC-A, EAN-13, GTIN-14) must pass their check digit, otherwise the read is ignored and scanning continues.
- On Receive Stock a scanned code goes through the same lookup as typing. An unknown barcode shows "Not registered" with a link that opens the
  product form with the barcode pre-filled. Nothing is created automatically.
- On the product form a scanned barcode is checked against existing products and a duplicate is flagged before saving.
- Camera access requires HTTPS (or localhost). If permission is denied, you can type the code in the scanner window instead.

## 7. What has and has not been verified
Run for real by the author (using a small stand-in test runner, not Vitest itself): the logic tests for row validation,
barcode/code lookup, and ledger filtering/sorting (26 assertions passed). All 36 source files parse as valid TypeScript/TSX.

NOT run: `npm install`, type-check, `vite build`, Vitest (validation and outbox/IndexedDB tests need packages),
any SQL against Postgres, any browser test. Not automated: offline app-shell opening and installability on a real phone
(manual check: load once online, enable airplane mode, reopen the app).

## 8. Known limitations (Level 1)
- Saving a product and linking suppliers are separate requests (not one transaction); a link failure is reported.
- Receiving is owner/admin only; staff roles exist in the schema but have no UI yet.
- Hold/release/discard is available on the Batch Ledger (owner/admin). Each batch has a History page (Ledger > History) showing every movement and hold/discard with a running balance, who did it, and a check that the movements add up to the ledger quantity.
- Camera scanning needs the HTTPS deployed app and a real phone to verify; it has not been tested on a device. Bluetooth/USB scanners that type into a field also work with the same lookup (untested).
- Ledger loads up to 2,000 batches (earliest expiry first) and filters in the browser.
- "Expired" means the printed date is before today in the shop timezone; the printed date itself counts as in date.
- No FEFO sales, forecasting, purchasing or LPO yet, by design.
