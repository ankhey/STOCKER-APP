// Run after `npm run build`. Verifies the generated PWA artefacts; it does not test a live browser.
import { existsSync, readFileSync } from 'node:fs';

const fail = [];
const need = (cond, msg) => { if (!cond) fail.push(msg); };

need(existsSync('dist/manifest.webmanifest'), 'dist/manifest.webmanifest missing');
need(existsSync('dist/sw.js'), 'dist/sw.js (service worker) missing');
need(existsSync('dist/index.html'), 'dist/index.html missing');

if (existsSync('dist/manifest.webmanifest')) {
  const m = JSON.parse(readFileSync('dist/manifest.webmanifest', 'utf8'));
  for (const k of ['name', 'short_name', 'theme_color', 'background_color', 'start_url']) need(m[k], `manifest.${k} missing`);
  need(m.display === 'standalone', 'manifest.display should be standalone');
  const sizes = (m.icons ?? []).map((i) => i.sizes);
  need(sizes.includes('192x192') && sizes.includes('512x512'), 'manifest needs 192x192 and 512x512 icons');
  for (const i of m.icons ?? []) need(existsSync(`dist/${i.src.replace(/^\//, '')}`), `icon file missing: ${i.src}`);
}
if (existsSync('dist/sw.js')) {
  const sw = readFileSync('dist/sw.js', 'utf8');
  need(sw.includes('index.html'), 'service worker does not precache index.html (app shell)');
  need(!/supabase\.co/.test(sw), 'service worker must not reference Supabase (private data is never cached)');
}
if (fail.length) { console.error('PWA check FAILED:\n- ' + fail.join('\n- ')); process.exit(1); }
console.log('PWA check passed: manifest valid, service worker generated and precaches the app shell.');
