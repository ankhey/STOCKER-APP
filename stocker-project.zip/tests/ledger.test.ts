import { describe, expect, it } from 'vitest';
import { applyLedgerFilters, emptyFilters, LedgerRow, safetyActions } from '../src/domain/ledger';

const r = (o: Partial<LedgerRow>): LedgerRow => ({
  batch_id: 'b', product_id: 'p1', product_code: '000001', product_name: 'Beef', barcode: null, category: 'uncooked',
  supplier_id: 's1', supplier_name: 'S1', storage_condition: 'chilled', supplier_batch_number: null,
  delivery_date: '2026-10-20', production_date: null, printed_expiry_date: '2026-11-01', quantity_received: 10,
  quantity_remaining: 10, batch_status: 'in_date', days_to_expiry: 7, eligible_for_sale: true, safety_status: 'ok', safety_note: null, ...o
});
const rows = [
  r({ batch_id: 'late', printed_expiry_date: '2026-12-15' }),
  r({ batch_id: 'expired', printed_expiry_date: '2026-10-01', batch_status: 'expired', days_to_expiry: -24 }),
  r({ batch_id: 'soon', printed_expiry_date: '2026-10-28', batch_status: 'expiring_soon', supplier_id: 's2', category: 'cooked', storage_condition: 'frozen' }),
  r({ batch_id: 'empty', printed_expiry_date: '2026-10-10', quantity_remaining: 0, batch_status: 'depleted' })
];
const ids = (f: Partial<typeof emptyFilters>) => applyLedgerFilters(rows, { ...emptyFilters, ...f }).map((x) => x.batch_id);

describe('batch ledger', () => {
  it('sorts by earliest printed expiry first', () => { expect(ids({ status: 'all' })).toEqual(['expired', 'empty', 'soon', 'late']); });
  it('hides depleted batches by default ("open")', () => { expect(ids({})).not.toContain('empty'); });
  it('filters by status, supplier, category and storage', () => {
    expect(ids({ status: 'expired' })).toEqual(['expired']);
    expect(ids({ supplierId: 's2' })).toEqual(['soon']);
    expect(ids({ category: 'cooked' })).toEqual(['soon']);
    expect(ids({ storage: 'frozen' })).toEqual(['soon']);
  });
  it('filters by expiry and delivery date ranges', () => {
    expect(ids({ status: 'all', expiryFrom: '2026-10-05', expiryTo: '2026-11-01' })).toEqual(['empty', 'soon']);
    expect(ids({ status: 'all', deliveryFrom: '2026-10-21' })).toEqual([]);
  });
  it('keeps expired and expiring-soon distinct', () => {
    const all = applyLedgerFilters(rows, { ...emptyFilters, status: 'all' });
    expect(new Set(all.map((x) => x.batch_status)).has('expired')).toBe(true);
    expect(new Set(all.map((x) => x.batch_status)).has('expiring_soon')).toBe(true);
  });
});

describe('batch hold / release / discard rules', () => {
  const to = (o: Partial<LedgerRow>) => safetyActions(r(o)).map((a) => a.to);
  it('offers hold and discard for a normal batch with stock', () => { expect(to({})).toEqual(['on_hold', 'discarded']); });
  it('offers release and discard for a held batch', () => { expect(to({ safety_status: 'on_hold' })).toEqual(['ok', 'discarded']); });
  it('offers nothing for a discarded batch (final)', () => { expect(to({ safety_status: 'discarded' })).toEqual([]); });
  it('offers nothing to hold or discard when no stock remains, but still allows releasing a hold', () => {
    expect(to({ quantity_remaining: 0 })).toEqual([]);
    expect(to({ quantity_remaining: 0, safety_status: 'on_hold' })).toEqual(['ok']);
  });
  it('requires a reason to hold or discard but not to release', () => {
    const a = safetyActions(r({ safety_status: 'on_hold' }));
    expect(a.find((x) => x.to === 'ok')?.needsNote).toBe(false);
    expect(a.find((x) => x.to === 'discarded')?.needsNote).toBe(true);
  });
});
