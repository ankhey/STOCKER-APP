import { describe, expect, it } from 'vitest';
import { buildPayload, checkHeader, checkRow, duplicateRowKeys, freshDraft, isIsoDate, newRow, RowInput } from '../src/domain/receipt';

const product = { default_storage_condition: 'chilled' as const, active: true };
const row = (o: Partial<RowInput> = {}): RowInput => ({
  ...newRow(), code: '000123', productId: 'p1', storage: 'chilled', batchNumber: 'L1', expiry: '2026-11-30', qty: '10', ...o
});
const ctx = { deliveryDate: '2026-10-25', product, supplierLinked: true };

describe('receiving row validation', () => {
  it('accepts a good row', () => { expect(checkRow(row(), ctx).errors).toEqual([]); });
  it('requires a printed expiry date', () => { expect(checkRow(row({ expiry: '' }), ctx).errors.join()).toMatch(/expiry date is required/i); });
  it('rejects an impossible date', () => { expect(isIsoDate('2026-02-30')).toBe(false); expect(checkRow(row({ expiry: '2026-02-30' }), ctx).errors.length).toBeGreaterThan(0); });
  it('rejects expiry before the delivery date', () => { expect(checkRow(row({ expiry: '2026-10-01' }), ctx).errors.join()).toMatch(/before the delivery date/i); });
  it('rejects production date after expiry', () => { expect(checkRow(row({ production: '2026-12-01' }), ctx).errors.join()).toMatch(/after the printed expiry/i); });
  it.each(['-5', '0', '1.5', 'abc', ''])('rejects quantity %j', (qty) => { expect(checkRow(row({ qty }), ctx).errors.join()).toMatch(/quantity/i); });
  it('rejects a negative cost', () => { expect(checkRow(row({ cost: '-1' }), ctx).errors.join()).toMatch(/cost/i); });
  it('blocks an unresolved product and an inactive product', () => {
    expect(checkRow(row({ productId: null }), { ...ctx, product: null }).errors.join()).toMatch(/not found/i);
    expect(checkRow(row(), { ...ctx, product: { ...product, active: false } }).errors.join()).toMatch(/inactive/i);
  });
  it('warns, but does not block, when the product is not linked to the supplier', () => {
    const c = checkRow(row(), { ...ctx, supplierLinked: false });
    expect(c.errors).toEqual([]);
    expect(c.warnings.join()).toMatch(/not linked/i);
  });
  it('warns when storage differs from the default and never changes the expiry', () => {
    const r = row({ storage: 'frozen', expiry: '2026-11-30' });
    const c = checkRow(r, ctx);
    expect(c.warnings.join()).toMatch(/never adjusted/i);
    expect(buildPayload('shop', { ...freshDraft(), supplierId: 's', rows: [r] }).p_rows[0].printed_expiry_date).toBe('2026-11-30');
  });
});

describe('delivery with multiple rows', () => {
  it('builds one payload with every row and a stable idempotency key', () => {
    const d = { ...freshDraft(), supplierId: 's1', rows: [row({ qty: '5' }), row({ productId: 'p2', qty: '7', cost: '120.50', batchNumber: ' B2 ' })] };
    const p = buildPayload('shop', d);
    expect(p.p_rows).toHaveLength(2);
    expect(p.p_rows[1]).toMatchObject({ product_id: 'p2', quantity_received: 7, purchase_cost_per_packet: 120.5, supplier_batch_number: 'B2' });
    expect(p.p_idempotency_key).toBe(d.idempotencyKey);
  });
  it('requires a supplier and flags repeated rows', () => {
    expect(checkHeader({ supplierId: '', deliveryDate: '2026-10-25' }).errors.join()).toMatch(/supplier/i);
    const a = row(); const b = row();
    expect(duplicateRowKeys([a, b]).size).toBe(2);
    expect(duplicateRowKeys([a, row({ expiry: '2026-12-01' })]).size).toBe(0);
  });
});
