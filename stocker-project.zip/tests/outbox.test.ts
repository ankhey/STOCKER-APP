import { beforeEach, describe, expect, it } from 'vitest';
import { retryPending, submitReceipt, SendDeps, ReceiptResult } from '../src/data/receipts';
import { buildPayload, freshDraft, newRow } from '../src/domain/receipt';
import { closeDb, clearDraft, listPending, loadDraft, removePending, saveDraft } from '../src/lib/idb';

const payload = () => buildPayload('shop', { ...freshDraft(), supplierId: 's1', rows: [
  { ...newRow(), productId: 'p1', storage: 'chilled', expiry: '2026-12-01', qty: '3' },
  { ...newRow(), productId: 'p2', storage: 'frozen', expiry: '2027-01-01', qty: '4' }
] });

/** A fake server with the same idempotency behaviour as receive_delivery. */
function fakeServer(failWith?: () => unknown) {
  const deliveries = new Map<string, ReceiptResult>();
  let batchesWritten = 0;
  const deps: SendDeps = {
    isOnline: () => true,
    send: async (p) => {
      if (failWith) throw failWith();
      const hit = deliveries.get(p.p_idempotency_key);
      if (hit) return { ...hit, duplicate: true };
      batchesWritten += p.p_rows.length;
      const r = { duplicate: false, delivery_id: `d-${deliveries.size}`, batch_ids: p.p_rows.map((_, i) => `b${i}`) };
      deliveries.set(p.p_idempotency_key, r);
      return r;
    }
  };
  return { deps, get batchesWritten() { return batchesWritten; } };
}
const networkDown = () => ({ message: 'TypeError: Failed to fetch' });

beforeEach(async () => {
  for (const p of await listPending()) await removePending(p.idempotencyKey);
  await clearDraft('shop');
});

describe('local data vs cloud-confirmed data', () => {
  it('reports "confirmed" only when the server acknowledged the receipt', async () => {
    const s = fakeServer();
    const o = await submitReceipt(payload(), 'x', s.deps);
    expect(o.kind).toBe('confirmed');
    expect(await listPending()).toHaveLength(0);
  });
  it('queues locally and never reports "confirmed" when offline', async () => {
    const s = fakeServer();
    const o = await submitReceipt(payload(), 'x', { ...s.deps, isOnline: () => false });
    expect(o.kind).toBe('queued');
    expect(s.batchesWritten).toBe(0);
    expect(await listPending()).toHaveLength(1);
  });
  it('treats a failed database request as unconfirmed and keeps it for retry', async () => {
    const s = fakeServer(networkDown);
    const o = await submitReceipt(payload(), 'x', s.deps);
    expect(o.kind).toBe('queued');
    expect(await listPending()).toHaveLength(1);
  });
  it('returns "rejected" for a server refusal and does not queue it', async () => {
    const s = fakeServer(() => ({ message: 'row 2: printed expiry date is required', code: '22023' }));
    const o = await submitReceipt(payload(), 'x', s.deps);
    expect(o).toMatchObject({ kind: 'rejected' });
    expect(await listPending()).toHaveLength(0);
  });
});

describe('duplicate receipt submission', () => {
  it('writes the delivery once even if the same receipt is sent twice', async () => {
    const s = fakeServer();
    const p = payload();
    await submitReceipt(p, 'x', s.deps);
    const second = await submitReceipt(p, 'x', s.deps);
    expect(second.kind === 'confirmed' && second.result.duplicate).toBe(true);
    expect(s.batchesWritten).toBe(2);
  });
  it('a timeout after the server committed is safe to retry', async () => {
    const s = fakeServer();
    const p = payload();
    await s.deps.send(p);                                  // server committed, but the client never heard back
    await submitReceipt(p, 'x', { ...s.deps, isOnline: () => false });   // client queues it
    const r = await retryPending(s.deps);
    expect(r).toMatchObject({ sent: 0, duplicates: 1 });
    expect(s.batchesWritten).toBe(2);
    expect(await listPending()).toHaveLength(0);
  });
});

describe('explicit retry', () => {
  it('keeps items when still offline, then sends them once the connection returns', async () => {
    const p = payload();
    await submitReceipt(p, 'x', { ...fakeServer().deps, isOnline: () => false });
    expect(await retryPending(fakeServer(networkDown).deps)).toMatchObject({ sent: 0, stillPending: 1 });
    expect(await listPending()).toHaveLength(1);
    const s = fakeServer();
    expect(await retryPending(s.deps)).toMatchObject({ sent: 1 });
    expect(s.batchesWritten).toBe(2);
  });
  it('marks a server-rejected item instead of retrying it forever', async () => {
    await submitReceipt(payload(), 'x', { ...fakeServer().deps, isOnline: () => false });
    const r = await retryPending(fakeServer(() => ({ message: 'forbidden', code: '42501' })).deps);
    expect(r.rejected).toBe(1);
    expect((await listPending())[0].status).toBe('rejected');
  });
});

describe('restoration after a browser refresh', () => {
  it('restores an unsaved draft', async () => {
    const d = { ...freshDraft(), supplierId: 's1', noteRef: 'DN-77' };
    await saveDraft('shop', d);
    await closeDb();                                        // simulates the page being reloaded
    expect(await loadDraft('shop')).toEqual(d);
  });
  it('keeps unsynchronised receipts across a reload', async () => {
    await submitReceipt(payload(), 'x', { ...fakeServer().deps, isOnline: () => false });
    await closeDb();
    expect(await listPending()).toHaveLength(1);
  });
});
