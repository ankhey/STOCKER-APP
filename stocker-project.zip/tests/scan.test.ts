import { describe, expect, it } from 'vitest';
import { isPlausibleScan, isValidGtin, normalizeScan } from '../src/domain/scan';

describe('scanned barcode handling', () => {
  it('accepts valid EAN-13, UPC-A and EAN-8 check digits', () => {
    expect(isValidGtin('4006381333931')).toBe(true);
    expect(isValidGtin('036000291452')).toBe(true);
    expect(isValidGtin('96385074')).toBe(true);
  });
  it('rejects a misread (wrong check digit) retail-length number', () => {
    expect(isValidGtin('4006381333932')).toBe(false);
    expect(isPlausibleScan('4006381333932')).toBe(false);
  });
  it('accepts a 6-digit internal code label and non-numeric Code 128 text', () => {
    expect(isPlausibleScan('000123')).toBe(true);
    expect(isPlausibleScan('LOT-77A')).toBe(true);
  });
  it('rejects empty or too-short reads', () => {
    expect(isPlausibleScan('')).toBe(false);
    expect(isPlausibleScan('123')).toBe(false);
  });
  it('strips whitespace and control characters and caps the length', () => {
    expect(normalizeScan(' 4006 3813\n33931\u0000 ')).toBe('4006381333931');
    expect(normalizeScan('9'.repeat(100))).toHaveLength(64);
  });
});
