import { describe, expect, it } from 'vitest';
import { findProduct, isLinked } from '../src/domain/catalog';
import type { Product } from '../src/types/db';

const p = (o: Partial<Product>): Product => ({
  id: 'p1', shop_id: 's', internal_code: '000001', barcode: null, product_name: 'X', brand: null, category: 'cooked',
  default_storage_condition: 'frozen', packet_size: null, unit_of_measure: 'packets', selling_price: null,
  default_supplier_id: null, active: true, notes: null, ...o
});
const products = [p({ id: 'a', internal_code: '000123', product_name: 'Beef', barcode: '6001234567890' }), p({ id: 'b', internal_code: '000124', product_name: 'Pork' })];

describe('barcode / code lookup', () => {
  it('finds by six-digit internal code, preserving leading zeros', () => { expect(findProduct(products, '000123')?.id).toBe('a'); });
  it('finds by full barcode', () => { expect(findProduct(products, ' 6001234567890 ')?.id).toBe('a'); });
  it('returns null for unknown codes instead of creating anything', () => {
    expect(findProduct(products, '999999')).toBeNull();
    expect(findProduct(products, '')).toBeNull();
  });
  it('does not match a partial barcode', () => { expect(findProduct(products, '600123')).toBeNull(); });
  it('reports whether a product is linked to a supplier', () => {
    const c = { links: [{ supplier_id: 's1', product_id: 'a' }] };
    expect(isLinked(c, 's1', 'a')).toBe(true);
    expect(isLinked(c, 's2', 'a')).toBe(false);
  });
});
