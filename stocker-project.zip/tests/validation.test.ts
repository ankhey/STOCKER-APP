import { describe, expect, it } from 'vitest';
import { productSchema } from '../src/validation/product';
import { scheduleSchema, supplierOrderSchema, supplierSchema } from '../src/validation/supplier';
import { toAppError } from '../src/lib/errors';

const goodProduct = {
  internal_code: '000123', barcode: '6001234567890', product_name: 'Beef sausages', brand: '', category: 'uncooked',
  default_storage_condition: 'chilled', packet_size: '500 g', selling_price: '', default_supplier_id: '', active: true, notes: ''
};

describe('product registration validation', () => {
  it('accepts a valid product, keeps leading zeros and nulls empty optionals', () => {
    const r = productSchema.parse(goodProduct);
    expect(r.internal_code).toBe('000123');
    expect(r.brand).toBeNull();
    expect(r.selling_price).toBeNull();
    expect(r.default_supplier_id).toBeNull();
  });
  it('allows a product with no barcode', () => {
    expect(productSchema.parse({ ...goodProduct, barcode: '' }).barcode).toBeNull();
  });
  it.each(['12345', '1234567', '12a456', ''])('rejects internal code %j', (code) => {
    expect(productSchema.safeParse({ ...goodProduct, internal_code: code }).success).toBe(false);
  });
  it('rejects a negative selling price and a missing name', () => {
    expect(productSchema.safeParse({ ...goodProduct, selling_price: '-1' }).success).toBe(false);
    expect(productSchema.safeParse({ ...goodProduct, product_name: '  ' }).success).toBe(false);
  });
});

describe('duplicate detection (database error mapping)', () => {
  it('maps a duplicate internal code to that field', () => {
    const e = toAppError({ code: '23505', message: 'duplicate key value violates unique constraint "products_shop_id_internal_code_key"' });
    expect(e.field).toBe('internal_code');
  });
  it('maps a duplicate barcode to that field', () => {
    const e = toAppError({ code: '23505', message: 'duplicate key value violates unique constraint "products_shop_id_barcode_key"' });
    expect(e.field).toBe('barcode');
  });
  it('flags network failures as offline and says nothing was saved', () => {
    const e = toAppError({ message: 'TypeError: Failed to fetch' });
    expect(e.offline).toBe(true);
    expect(e.message).toMatch(/nothing was saved/i);
  });
});

describe('supplier and schedule validation', () => {
  it('accepts a supplier and rejects a bad email', () => {
    const base = { supplier_code: 'SUP-001', supplier_name: 'A', contact_person: '', phone: '', email: '', address: '', active: true, notes: '' };
    expect(supplierSchema.safeParse(base).success).toBe(true);
    expect(supplierSchema.safeParse({ ...base, email: 'nope' }).success).toBe(false);
    expect(supplierSchema.safeParse({ ...base, supplier_code: '' }).success).toBe(false);
  });
  it('keeps an unknown cutoff time as null and never invents one', () => {
    const r = scheduleSchema.parse({ order_day_of_week: '0', expected_delivery_day_of_week: '2', schedule_type: 'regular', order_cutoff_time: '', notes: '', active: true });
    expect(r.order_cutoff_time).toBeNull();
    expect(r.order_day_of_week).toBe(0);
    expect(scheduleSchema.safeParse({ order_day_of_week: 1, expected_delivery_day_of_week: 3, schedule_type: 'regular', order_cutoff_time: '25:00', notes: '', active: true }).success).toBe(false);
  });
  it('rejects an arrival date before the order date', () => {
    const r = supplierOrderSchema.safeParse({ order_date: '2026-10-20', promised_delivery_date: '', actual_arrival_date: '2026-10-19', reference: '', notes: '' });
    expect(r.success).toBe(false);
  });
});
