import { describe, expect, it } from 'vitest';
import { buildTimeline, reconciles, MovementRow, SafetyEventRow } from '../src/domain/history';

const mv = (o: Partial<MovementRow>): MovementRow => ({ id: 'm', movement_type: 'receipt', quantity_change: 10, reference: null, reason: null, created_by: 'u', created_at: '2026-10-20T08:00:00Z', ...o });
const ev = (o: Partial<SafetyEventRow>): SafetyEventRow => ({ id: 'e', from_status: 'ok', to_status: 'on_hold', note: 'fridge failure', created_by: 'u', created_at: '2026-10-21T08:00:00Z', ...o });

describe('batch history timeline', () => {
  it('orders oldest first and keeps a running balance', () => {
    const t = buildTimeline(
      [mv({ id: 'm2', movement_type: 'sale', quantity_change: -3, created_at: '2026-10-22T08:00:00Z' }), mv({ id: 'm1' })], []);
    expect(t.map((x) => x.balance)).toEqual([10, 7]);
    expect(t.map((x) => x.title)).toEqual(['Received', 'Sold']);
  });
  it('interleaves safety events and shows the balance at that moment', () => {
    const t = buildTimeline([mv({ id: 'm1' })], [ev({})]);
    expect(t.map((x) => x.kind)).toEqual(['movement', 'safety']);
    expect(t[1].balance).toBe(10);
    expect(t[1].title).toBe('Normal → On hold');
  });
  it('puts the wastage movement before the discard event when they share a timestamp', () => {
    const at = '2026-10-23T09:00:00Z';
    const t = buildTimeline(
      [mv({ id: 'a' }), mv({ id: 'w', movement_type: 'wastage', quantity_change: -10, reference: 'batch discarded', reason: 'thrown away', created_at: at })],
      [ev({ id: 'd', from_status: 'on_hold', to_status: 'discarded', note: 'thrown away', created_at: at })]);
    expect(t.map((x) => x.title)).toEqual(['Received', 'Wastage', 'On hold → Discarded']);
    expect(t[2].balance).toBe(0);
  });
  it('detects when movements do not match the ledger quantity', () => {
    const t = buildTimeline([mv({})], []);
    expect(reconciles(t, 10)).toBe(true);
    expect(reconciles(t, 9)).toBe(false);
    expect(reconciles([], 0)).toBe(true);
  });
});
