/// <reference types="vitest" />
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'prompt', // the user chooses when to apply an update; avoids reloading mid-form
      includeAssets: ['icons/icon.svg'],
      manifest: {
        name: 'Sausage Stock Manager',
        short_name: 'Stocker',
        description: 'Batch-level stock receiving and expiry tracking for sausage retail.',
        theme_color: '#9a3412',
        background_color: '#fffaf5',
        display: 'standalone',
        start_url: '/',
        scope: '/',
        icons: [
          { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' },
          { src: 'icons/icon-512-maskable.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }
        ]
      },
      workbox: {
        // App shell + static assets ONLY. Supabase API/auth responses are never cached.
        globPatterns: ['**/*.{js,css,html,svg,png,ico,webmanifest}'],
        navigateFallback: '/index.html',
        navigateFallbackDenylist: [/^\/rest\//, /^\/auth\//],
        runtimeCaching: []
      }
    })
  ],
  test: { environment: 'jsdom', globals: true, setupFiles: ['./src/test-setup.ts'] }
});
