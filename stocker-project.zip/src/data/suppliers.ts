import { supabase } from '../lib/supabase';
import { toAppError } from '../lib/errors';
import type { Supplier, SupplierOrder, SupplierProduct, SupplierSchedule } from '../types/db';

function check<T>(res: { data: T | null; error: unknown }): T {
  if (res.error) throw toAppError(res.error);
  return res.data as T;
}

export const listSuppliers = async (): Promise<Supplier[]> =>
  check(await supabase.from('suppliers').select('*').order('supplier_name'));

export async function saveSupplier(shopId: string, id: string | null, v: Record<string, unknown>) {
  const res = id
    ? await supabase.from('suppliers').update(v).eq('id', id)
    : await supabase.from('suppliers').insert({ ...v, shop_id: shopId });
  if (res.error) throw toAppError(res.error);
}

export const listSchedules = async (supplierId: string): Promise<SupplierSchedule[]> =>
  check(await supabase.from('supplier_schedules').select('*').eq('supplier_id', supplierId)
    .order('order_day_of_week'));

export async function saveSchedule(shopId: string, supplierId: string, id: string | null, v: Record<string, unknown>) {
  const res = id
    ? await supabase.from('supplier_schedules').update(v).eq('id', id)
    : await supabase.from('supplier_schedules').insert({ ...v, shop_id: shopId, supplier_id: supplierId });
  if (res.error) throw toAppError(res.error);
}

export const listSupplierOrders = async (supplierId: string): Promise<SupplierOrder[]> =>
  check(await supabase.from('supplier_orders').select('*').eq('supplier_id', supplierId)
    .order('order_date', { ascending: false }).limit(50));

export async function saveSupplierOrder(shopId: string, supplierId: string, id: string | null, v: Record<string, unknown>) {
  const res = id
    ? await supabase.from('supplier_orders').update(v).eq('id', id)
    : await supabase.from('supplier_orders').insert({ ...v, shop_id: shopId, supplier_id: supplierId });
  if (res.error) throw toAppError(res.error);
}

export const listLinksForSupplier = async (supplierId: string) =>
  check(await supabase.from('supplier_products')
    .select('*, products(internal_code, product_name)').eq('supplier_id', supplierId)) as
    (SupplierProduct & { products: { internal_code: string; product_name: string } | null })[];

export async function updateSupplierProduct(id: string, v: Record<string, unknown>) {
  const res = await supabase.from('supplier_products').update(v).eq('id', id);
  if (res.error) throw toAppError(res.error);
}
