import { supabase } from '../lib/supabase';
import { toAppError } from '../lib/errors';
import { enqueue, listPending, markRejected, removePending } from '../lib/idb';
import type { ReceiptPayload } from '../domain/receipt';

export interface ReceiptResult { duplicate: boolean; delivery_id: string; batch_ids: string[] }

export async function sendReceipt(payload: ReceiptPayload): Promise<ReceiptResult> {
  const { data, error } = await supabase.rpc('receive_delivery', payload);
  if (error) throw toAppError(error);
  return data as ReceiptResult;
}

/**
 * confirmed: the database acknowledged the receipt (server-confirmed).
 * queued:    stored ONLY on this device; not in the ledger until a later sync succeeds.
 * rejected:  the server refused it (nothing was written); the form stays editable.
 */
export type SubmitOutcome =
  | { kind: 'confirmed'; result: ReceiptResult }
  | { kind: 'queued'; reason: string }
  | { kind: 'rejected'; message: string };

export interface SendDeps {
  send: (p: ReceiptPayload) => Promise<ReceiptResult>;
  isOnline: () => boolean;
}
const defaultDeps: SendDeps = { send: sendReceipt, isOnline: () => navigator.onLine };

export async function submitReceipt(payload: ReceiptPayload, summary: string, deps: SendDeps = defaultDeps): Promise<SubmitOutcome> {
  const queue = (reason: string) =>
    enqueue({ idempotencyKey: payload.p_idempotency_key, payload, summary, createdAt: new Date().toISOString(), status: 'pending' })
      .then((): SubmitOutcome => ({ kind: 'queued', reason }));

  if (!deps.isOnline()) return queue('You are offline.');
  try {
    return { kind: 'confirmed', result: await deps.send(payload) };
  } catch (e) {
    const ae = toAppError(e);
    if (ae.offline) {
      // The request may or may not have reached the server. The idempotency key makes a later retry safe either way.
      return queue('The connection failed, so it is not known whether the server received it.');
    }
    return { kind: 'rejected', message: ae.message };
  }
}

export interface RetrySummary { sent: number; duplicates: number; rejected: number; stillPending: number }

/** Explicit retry of the outbox. Same idempotency key => a retry can never create a second receipt. */
export async function retryPending(deps: SendDeps = defaultDeps): Promise<RetrySummary> {
  const s: RetrySummary = { sent: 0, duplicates: 0, rejected: 0, stillPending: 0 };
  const items = (await listPending()).filter((p) => p.status === 'pending');
  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    try {
      const r = await deps.send(item.payload);
      await removePending(item.idempotencyKey);
      if (r.duplicate) s.duplicates++; else s.sent++;
    } catch (e) {
      const ae = toAppError(e);
      if (ae.offline) { s.stillPending = items.length - i; break; }
      await markRejected(item.idempotencyKey, ae.message);
      s.rejected++;
    }
  }
  return s;
}
