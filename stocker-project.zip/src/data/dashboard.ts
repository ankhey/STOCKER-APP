import { supabase } from '../lib/supabase';
import { toAppError } from '../lib/errors';
import type { BatchStatus } from '../domain/ledger';

export interface DashboardData {
  productCount: number;
  activeSuppliers: number;
  packetsInStock: number;
  packetsExpired: number;
  expiringSoon: number;
  expired: number;
  attention: { batch_id: string; product_code: string; product_name: string; printed_expiry_date: string; quantity_remaining: number; batch_status: BatchStatus }[];
  recent: { id: string; delivery_date: string; delivery_note_ref: string | null; supplier: string; batches: number }[];
}

export async function loadDashboard(): Promise<DashboardData> {
  const [p, s, l, d] = await Promise.all([
    supabase.from('products').select('id', { count: 'exact', head: true }),
    supabase.from('suppliers').select('id', { count: 'exact', head: true }).eq('active', true),
    supabase.from('batch_ledger')
      .select('batch_id, product_code, product_name, printed_expiry_date, quantity_remaining, batch_status')
      .order('printed_expiry_date', { ascending: true }).limit(5000),
    supabase.from('deliveries')
      .select('id, delivery_date, delivery_note_ref, suppliers(supplier_name), inventory_batches(count)')
      .order('created_at', { ascending: false }).limit(5)
  ]);
  for (const r of [p, s, l, d]) if (r.error) throw toAppError(r.error);

  const rows = (l.data ?? []) as DashboardData['attention'];
  const live = rows.filter((r) => r.batch_status !== 'discarded' && r.quantity_remaining > 0);
  return {
    productCount: p.count ?? 0,
    activeSuppliers: s.count ?? 0,
    packetsInStock: live.reduce((a, r) => a + r.quantity_remaining, 0),
    packetsExpired: live.filter((r) => r.batch_status === 'expired').reduce((a, r) => a + r.quantity_remaining, 0),
    expiringSoon: live.filter((r) => r.batch_status === 'expiring_soon').length,
    expired: live.filter((r) => r.batch_status === 'expired').length,
    attention: live.filter((r) => r.batch_status === 'expired' || r.batch_status === 'expiring_soon').slice(0, 6),
    recent: ((d.data ?? []) as any[]).map((x) => ({
      id: x.id, delivery_date: x.delivery_date, delivery_note_ref: x.delivery_note_ref,
      supplier: x.suppliers?.supplier_name ?? 'Unknown', batches: x.inventory_batches?.[0]?.count ?? 0
    }))
  };
}
