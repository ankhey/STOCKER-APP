import { supabase } from '../lib/supabase';
import { toAppError } from '../lib/errors';
import type { Product, SupplierProduct } from '../types/db';

function check<T>(res: { data: T | null; error: unknown }): T {
  if (res.error) throw toAppError(res.error);
  return res.data as T;
}

export const listProducts = async (): Promise<Product[]> =>
  check(await supabase.from('products').select('*').order('product_name'));

export async function suggestInternalCode(shopId: string): Promise<string> {
  return check(await supabase.rpc('next_internal_code', { p_shop_id: shopId })) as string;
}

export const listProductLinks = async (productId: string): Promise<SupplierProduct[]> =>
  check(await supabase.from('supplier_products').select('*').eq('product_id', productId));

/**
 * Saves the product, then reconciles supplier links.
 * NOTE: these are separate requests, not one transaction. If linking fails after the product row is
 * saved, the caller is told exactly that so the owner can retry the links.
 */
export async function saveProduct(
  shopId: string, id: string | null, v: Record<string, unknown>,
  supplierIds: string[], existingLinks: SupplierProduct[]
): Promise<{ productId: string; linkError: string | null }> {
  let productId = id;
  if (id) {
    const { error } = await supabase.from('products').update(v).eq('id', id);
    if (error) throw toAppError(error);
  } else {
    const { data, error } = await supabase.from('products').insert({ ...v, shop_id: shopId }).select('id').single();
    if (error) throw toAppError(error);
    productId = data.id as string;
  }
  try {
    const have = new Set(existingLinks.map((l) => l.supplier_id));
    const want = new Set(supplierIds);
    const add = [...want].filter((s) => !have.has(s))
      .map((supplier_id) => ({ shop_id: shopId, supplier_id, product_id: productId! }));
    const remove = [...have].filter((s) => !want.has(s));
    if (add.length) {
      const { error } = await supabase.from('supplier_products').insert(add);
      if (error) throw error;
    }
    for (const sid of remove) {
      const { error } = await supabase.from('supplier_products').delete()
        .eq('product_id', productId!).eq('supplier_id', sid);
      if (error) throw error;
    }
    return { productId: productId!, linkError: null };
  } catch (e) {
    return { productId: productId!, linkError: toAppError(e).message };
  }
}

/** Single lookup path for manual entry now and a camera scanner later: code OR full barcode. */
export async function lookupProduct(codeOrBarcode: string): Promise<Product | null> {
  const q = codeOrBarcode.trim();
  if (!q) return null;
  const col = /^\d{6}$/.test(q) ? 'internal_code' : 'barcode';
  const { data, error } = await supabase.from('products').select('*').eq(col, q).maybeSingle();
  if (error) throw toAppError(error);
  return data as Product | null;
}
