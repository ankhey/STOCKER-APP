import { supabase } from '../lib/supabase';
import { toAppError } from '../lib/errors';
import { sortByExpiry, LedgerRow, SafetyStatus } from '../domain/ledger';

export const LEDGER_LIMIT = 2000;

export async function fetchLedger(): Promise<LedgerRow[]> {
  const { data, error } = await supabase.from('batch_ledger').select('*')
    .order('printed_expiry_date', { ascending: true }).limit(LEDGER_LIMIT);
  if (error) throw toAppError(error);
  return sortByExpiry(data as LedgerRow[]);
}

export async function setBatchSafety(batchId: string, status: SafetyStatus, note: string): Promise<{ wasted_packets: number }> {
  const { data, error } = await supabase.rpc('set_batch_safety', { p_batch_id: batchId, p_status: status, p_note: note.trim() || null });
  if (error) throw toAppError(error);
  return data as { wasted_packets: number };
}
