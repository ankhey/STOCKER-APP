import { supabase } from '../lib/supabase';
import { toAppError } from '../lib/errors';
import { loadCatalogCache, saveCatalogCache } from '../lib/idb';
import type { Catalog } from '../domain/catalog';
import type { Product } from '../types/db';

/** Loads products + supplier links. If the network is down, falls back to the last copy stored on this device. */
export async function loadCatalog(shopId: string): Promise<Catalog> {
  try {
    const p = await supabase.from('products').select('*').order('product_name');
    if (p.error) throw p.error;
    const l = await supabase.from('supplier_products').select('supplier_id, product_id');
    if (l.error) throw l.error;
    const fresh = { products: p.data as Product[], links: l.data as Catalog['links'] };
    saveCatalogCache(shopId, fresh).catch(() => undefined);
    return { ...fresh, fromCache: false };
  } catch (e) {
    const ae = toAppError(e);
    if (ae.offline) {
      const cached = await loadCatalogCache(shopId).catch(() => null);
      if (cached) return { ...cached, fromCache: true };
    }
    throw ae;
  }
}
