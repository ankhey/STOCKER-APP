import { supabase } from '../lib/supabase';
import { AppError, toAppError } from '../lib/errors';
import type { LedgerRow } from '../domain/ledger';
import type { MovementRow, SafetyEventRow } from '../domain/history';

export interface BatchHistory {
  batch: LedgerRow & { delivery_id: string };
  delivery: { delivery_note_ref: string | null; notes: string | null } | null;
  movements: MovementRow[];
  events: SafetyEventRow[];
}

export async function loadBatchHistory(batchId: string): Promise<BatchHistory> {
  const [b, m, e] = await Promise.all([
    supabase.from('batch_ledger').select('*').eq('batch_id', batchId).maybeSingle(),
    supabase.from('inventory_movements')
      .select('id, movement_type, quantity_change, reference, reason, created_by, created_at')
      .eq('batch_id', batchId).order('created_at', { ascending: true }),
    supabase.from('batch_safety_events')
      .select('id, from_status, to_status, note, created_by, created_at')
      .eq('batch_id', batchId).order('created_at', { ascending: true })
  ]);
  for (const r of [b, m, e]) if (r.error) throw toAppError(r.error);
  if (!b.data) throw new AppError('Batch not found.');
  const batch = b.data as BatchHistory['batch'];
  const d = await supabase.from('deliveries').select('delivery_note_ref, notes').eq('id', batch.delivery_id).maybeSingle();
  if (d.error) throw toAppError(d.error);
  return { batch, delivery: d.data as BatchHistory['delivery'], movements: m.data as MovementRow[], events: e.data as SafetyEventRow[] };
}
