/** Pure helpers for scanned barcode text (kept separate from the camera code so they can be tested). */

export function normalizeScan(raw: string): string {
  // eslint-disable-next-line no-control-regex
  return raw.replace(/[\s\u0000-\u001f]/g, '').slice(0, 64);
}

const GTIN_LENGTHS = [8, 12, 13, 14];

/** Validates the check digit of EAN-8, UPC-A, EAN-13 and GTIN-14 codes. */
export function isValidGtin(code: string): boolean {
  if (!/^\d+$/.test(code) || !GTIN_LENGTHS.includes(code.length)) return false;
  const body = code.slice(0, -1);
  let sum = 0;
  for (let i = 0; i < body.length; i++) {
    const digit = Number(body[body.length - 1 - i]);
    sum += digit * (i % 2 === 0 ? 3 : 1);
  }
  return (10 - (sum % 10)) % 10 === Number(code[code.length - 1]);
}

/**
 * Camera misreads are common. A retail-length number (8/12/13/14 digits) must pass its check digit or it is
 * ignored and scanning continues. Other values (a 6-digit internal-code label, Code 128 text) are accepted.
 */
export function isPlausibleScan(code: string): boolean {
  if (code.length < 4) return false;
  if (/^\d+$/.test(code) && GTIN_LENGTHS.includes(code.length)) return isValidGtin(code);
  return true;
}
