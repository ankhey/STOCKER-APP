export interface MovementRow {
  id: string; movement_type: 'receipt' | 'sale' | 'adjustment' | 'return' | 'wastage';
  quantity_change: number; reference: string | null; reason: string | null; created_by: string | null; created_at: string;
}
export interface SafetyEventRow {
  id: string; from_status: 'ok' | 'on_hold' | 'discarded'; to_status: 'ok' | 'on_hold' | 'discarded';
  note: string | null; created_by: string | null; created_at: string;
}
export interface TimelineEntry {
  id: string; at: string; kind: 'movement' | 'safety'; title: string; detail: string | null;
  delta: number | null;     // packets added (+) or removed (-); null for safety events
  balance: number;          // packets remaining after this entry
  by: string | null;
}

const MOVEMENT_LABEL: Record<MovementRow['movement_type'], string> = {
  receipt: 'Received', sale: 'Sold', adjustment: 'Adjustment', return: 'Returned', wastage: 'Wastage'
};
const SAFETY_LABEL = { ok: 'Normal', on_hold: 'On hold', discarded: 'Discarded' } as const;

/**
 * Merges stock movements and safety events into one oldest-first timeline with a running balance.
 * Rows written in the same transaction share a timestamp, so movements sort before safety events on ties
 * (a discard posts its wastage first, then the status change).
 */
export function buildTimeline(movements: MovementRow[], events: SafetyEventRow[]): TimelineEntry[] {
  const items = [
    ...movements.map((m) => ({ at: m.created_at, order: 0, id: m.id, m: m, e: null as SafetyEventRow | null })),
    ...events.map((e) => ({ at: e.created_at, order: 1, id: e.id, m: null as MovementRow | null, e }))
  ].sort((a, b) => a.at.localeCompare(b.at) || a.order - b.order || a.id.localeCompare(b.id));

  let balance = 0;
  return items.map((it) => {
    if (it.m) {
      balance += it.m.quantity_change;
      const detail = [it.m.reference, it.m.reason].filter(Boolean).join(' · ') || null;
      return { id: it.id, at: it.at, kind: 'movement', title: MOVEMENT_LABEL[it.m.movement_type], detail,
        delta: it.m.quantity_change, balance, by: it.m.created_by } as TimelineEntry;
    }
    const e = it.e as SafetyEventRow;
    return { id: it.id, at: it.at, kind: 'safety', title: `${SAFETY_LABEL[e.from_status]} → ${SAFETY_LABEL[e.to_status]}`,
      detail: e.note, delta: null, balance, by: e.created_by } as TimelineEntry;
  });
}

/** True when the movements add up to the quantity the ledger shows. */
export const reconciles = (timeline: TimelineEntry[], quantityRemaining: number) =>
  (timeline.length ? timeline[timeline.length - 1].balance : 0) === quantityRemaining;
