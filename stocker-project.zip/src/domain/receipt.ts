import type { Product, StorageCondition } from '../types/db';

export interface RowInput {
  key: string;
  code: string;
  productId: string | null;
  storage: '' | StorageCondition;
  batchNumber: string;
  production: string;
  expiry: string;
  qty: string;
  cost: string;
}
export interface ReceiptDraft {
  idempotencyKey: string;
  supplierId: string;
  deliveryDate: string;
  noteRef: string;
  notes: string;
  rows: RowInput[];
}
export interface RpcRow {
  product_id: string;
  supplier_batch_number: string | null;
  production_date: string | null;
  printed_expiry_date: string;
  storage_condition: StorageCondition;
  quantity_received: number;
  purchase_cost_per_packet: number | null;
}
export interface ReceiptPayload {
  p_shop_id: string;
  p_idempotency_key: string;
  p_supplier_id: string;
  p_delivery_date: string;
  p_delivery_note_ref: string | null;
  p_notes: string | null;
  p_rows: RpcRow[];
}

export function uid(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  });
}
export const todayIso = () => new Date().toISOString().slice(0, 10);
export const newRow = (): RowInput => ({ key: uid(), code: '', productId: null, storage: '', batchNumber: '', production: '', expiry: '', qty: '', cost: '' });
export const freshDraft = (): ReceiptDraft => ({ idempotencyKey: uid(), supplierId: '', deliveryDate: todayIso(), noteRef: '', notes: '', rows: [newRow()] });

export function isIsoDate(s: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(`${s}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
}

export interface RowContext {
  deliveryDate: string;
  product: Pick<Product, 'default_storage_condition' | 'active'> | null;
  supplierLinked: boolean | null; // null = unknown (no product / no supplier yet)
}
export interface RowCheck { errors: string[]; warnings: string[] }

/** Blocking errors must be resolved before saving. Warnings are shown but do not block. */
export function checkRow(r: RowInput, ctx: RowContext): RowCheck {
  const errors: string[] = [];
  const warnings: string[] = [];
  const deliveryOk = isIsoDate(ctx.deliveryDate);

  if (!r.productId || !ctx.product) errors.push('Product not found. Enter a registered code or barcode, or register the product first.');
  else if (!ctx.product.active) errors.push('Product is inactive. Reactivate it before receiving stock.');
  if (!r.storage) errors.push('Choose chilled or frozen.');

  if (!r.expiry) errors.push('Printed expiry date is required.');
  else if (!isIsoDate(r.expiry)) errors.push('Printed expiry date is not a valid date.');
  else if (deliveryOk && r.expiry < ctx.deliveryDate) errors.push('Printed expiry is before the delivery date. Resolve this before receiving.');

  if (r.production) {
    if (!isIsoDate(r.production)) errors.push('Production date is not a valid date.');
    else {
      if (isIsoDate(r.expiry) && r.production > r.expiry) errors.push('Production date is after the printed expiry date.');
      if (deliveryOk && r.production > ctx.deliveryDate) errors.push('Production date is after the delivery date.');
    }
  }

  if (!/^\d+$/.test(r.qty.trim()) || Number(r.qty) < 1 || Number(r.qty) > 1_000_000) {
    errors.push('Quantity must be a whole number of packets, 1 or more.');
  }
  if (r.cost.trim() !== '' && (!Number.isFinite(Number(r.cost)) || Number(r.cost) < 0)) {
    errors.push('Purchase cost must be a number, 0 or more.');
  }

  if (ctx.supplierLinked === false) warnings.push('This product is not linked to the selected supplier.');
  if (ctx.product && r.storage && r.storage !== ctx.product.default_storage_condition) {
    warnings.push(`Received ${r.storage}; the product default is ${ctx.product.default_storage_condition}. Enter the expiry printed on this pack. It is never adjusted for storage.`);
  }
  if (!r.batchNumber.trim()) warnings.push('No supplier batch number entered.');
  return { errors, warnings };
}

export function checkHeader(d: Pick<ReceiptDraft, 'supplierId' | 'deliveryDate'>): RowCheck {
  const errors: string[] = [];
  const warnings: string[] = [];
  if (!d.supplierId) errors.push('Choose a supplier.');
  if (!isIsoDate(d.deliveryDate)) errors.push('Delivery date is not valid.');
  else if (d.deliveryDate > todayIso()) warnings.push('Delivery date is in the future.');
  return { errors, warnings };
}

/** Keys of rows that repeat the same product + batch number + expiry within one delivery. */
export function duplicateRowKeys(rows: RowInput[]): Set<string> {
  const seen = new Map<string, string>();
  const dup = new Set<string>();
  for (const r of rows) {
    if (!r.productId) continue;
    const id = `${r.productId}|${r.batchNumber.trim().toLowerCase()}|${r.expiry}|${r.storage}`;
    const first = seen.get(id);
    if (first) { dup.add(first); dup.add(r.key); } else seen.set(id, r.key);
  }
  return dup;
}

export function buildPayload(shopId: string, d: ReceiptDraft): ReceiptPayload {
  return {
    p_shop_id: shopId,
    p_idempotency_key: d.idempotencyKey,
    p_supplier_id: d.supplierId,
    p_delivery_date: d.deliveryDate,
    p_delivery_note_ref: d.noteRef.trim() || null,
    p_notes: d.notes.trim() || null,
    p_rows: d.rows.map((r) => ({
      product_id: r.productId as string,
      supplier_batch_number: r.batchNumber.trim() || null,
      production_date: r.production || null,
      printed_expiry_date: r.expiry,
      storage_condition: r.storage as StorageCondition,
      quantity_received: Number(r.qty),
      purchase_cost_per_packet: r.cost.trim() === '' ? null : Number(r.cost)
    }))
  };
}
