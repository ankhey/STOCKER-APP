export type BatchStatus = 'in_date' | 'expiring_soon' | 'expired' | 'on_hold' | 'depleted' | 'discarded';

export type SafetyStatus = 'ok' | 'on_hold' | 'discarded';

export interface LedgerRow {
  batch_id: string; product_id: string; product_code: string; product_name: string; barcode: string | null;
  category: 'cooked' | 'uncooked'; supplier_id: string; supplier_name: string;
  storage_condition: 'chilled' | 'frozen'; supplier_batch_number: string | null;
  delivery_date: string; production_date: string | null; printed_expiry_date: string;
  quantity_received: number; quantity_remaining: number; batch_status: BatchStatus;
  days_to_expiry: number; eligible_for_sale: boolean;
  safety_status: SafetyStatus; safety_note: string | null;
}
export interface LedgerFilters {
  search: string; supplierId: string; productId: string; category: string; storage: string;
  status: string; // 'open' | 'all' | a BatchStatus
  expiryFrom: string; expiryTo: string; deliveryFrom: string; deliveryTo: string;
}
export const emptyFilters: LedgerFilters = {
  search: '', supplierId: '', productId: '', category: '', storage: '', status: 'open',
  expiryFrom: '', expiryTo: '', deliveryFrom: '', deliveryTo: ''
};

/** Earliest printed expiry first; ties broken by delivery date then name so the order is stable. */
export function sortByExpiry<T extends Pick<LedgerRow, 'printed_expiry_date' | 'delivery_date' | 'product_name'>>(rows: T[]): T[] {
  return [...rows].sort((a, b) =>
    a.printed_expiry_date.localeCompare(b.printed_expiry_date) ||
    a.delivery_date.localeCompare(b.delivery_date) ||
    a.product_name.localeCompare(b.product_name));
}

export function applyLedgerFilters(rows: LedgerRow[], f: LedgerFilters): LedgerRow[] {
  const s = f.search.trim().toLowerCase();
  const out = rows.filter((r) =>
    (!s || r.product_name.toLowerCase().includes(s) || r.product_code.includes(s) ||
      (r.barcode ?? '').includes(s) || (r.supplier_batch_number ?? '').toLowerCase().includes(s)) &&
    (!f.supplierId || r.supplier_id === f.supplierId) &&
    (!f.productId || r.product_id === f.productId) &&
    (!f.category || r.category === f.category) &&
    (!f.storage || r.storage_condition === f.storage) &&
    (f.status === 'all' ||
      (f.status === 'open' ? r.quantity_remaining > 0 && r.batch_status !== 'discarded' : r.batch_status === f.status)) &&
    (!f.expiryFrom || r.printed_expiry_date >= f.expiryFrom) &&
    (!f.expiryTo || r.printed_expiry_date <= f.expiryTo) &&
    (!f.deliveryFrom || r.delivery_date >= f.deliveryFrom) &&
    (!f.deliveryTo || r.delivery_date <= f.deliveryTo));
  return sortByExpiry(out);
}

export const STATUS_LABEL: Record<BatchStatus, string> = {
  in_date: 'In date', expiring_soon: 'Expiring soon', expired: 'Expired – review',
  on_hold: 'On hold', depleted: 'Depleted', discarded: 'Discarded'
};

export interface SafetyAction { to: SafetyStatus; label: string; needsNote: boolean; destructive: boolean }

/** Which hold/release/discard actions make sense for a batch. Mirrors the database function's rules. */
export function safetyActions(r: Pick<LedgerRow, 'safety_status' | 'quantity_remaining'>): SafetyAction[] {
  if (r.safety_status === 'discarded') return [];
  const out: SafetyAction[] = [];
  if (r.safety_status === 'on_hold') out.push({ to: 'ok', label: 'Release', needsNote: false, destructive: false });
  if (r.safety_status === 'ok' && r.quantity_remaining > 0) out.push({ to: 'on_hold', label: 'Hold', needsNote: true, destructive: false });
  if (r.quantity_remaining > 0) out.push({ to: 'discarded', label: 'Discard', needsNote: true, destructive: true });
  return out;
}
