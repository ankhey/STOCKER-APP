import type { Product } from '../types/db';

export interface Catalog {
  products: Product[];
  links: { supplier_id: string; product_id: string }[];
  fromCache: boolean;
}

/**
 * One lookup path for typed entry now and a camera scanner later (a scanner just supplies the string).
 * A six-digit value is tried as an internal code first, then as a barcode.
 */
export function findProduct(products: Product[], input: string): Product | null {
  const q = input.trim();
  if (!q) return null;
  if (/^\d{6}$/.test(q)) {
    const byCode = products.find((p) => p.internal_code === q);
    if (byCode) return byCode;
  }
  return products.find((p) => p.barcode === q) ?? null;
}

export function isLinked(catalog: Pick<Catalog, 'links'>, supplierId: string, productId: string): boolean {
  return catalog.links.some((l) => l.supplier_id === supplierId && l.product_id === productId);
}
