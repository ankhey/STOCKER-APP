import { Route, Routes } from 'react-router-dom';
import { AuthProvider, useAuth } from './auth/AuthProvider';
import { BootstrapPage, LoginPage } from './auth/LoginPage';
import { Layout } from './components/Layout';
import { envErrors } from './lib/env';
import { ProductsPage } from './pages/ProductsPage';
import { SuppliersPage } from './pages/SuppliersPage';
import { SchedulesPage } from './pages/SchedulesPage';
import { SettingsPage } from './pages/SettingsPage';
import { ReceivePage } from './pages/ReceivePage';
import { LedgerPage } from './pages/LedgerPage';
import { BatchHistoryPage } from './pages/BatchHistoryPage';
import { DashboardPage } from './pages/DashboardPage';

function Gate() {
  const { session, shopId, loading, error } = useAuth();
  if (loading) return <p className="center-card muted">Loading…</p>;
  if (!session) return <LoginPage />;
  if (error && !shopId) return <main className="center-card"><p className="error" role="alert">{error}</p></main>;
  if (!shopId) return <BootstrapPage />;
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<DashboardPage />} />
        <Route path="products" element={<ProductsPage />} />
        <Route path="suppliers" element={<SuppliersPage />} />
        <Route path="schedules" element={<SchedulesPage />} />
        <Route path="receive" element={<ReceivePage />} />
        <Route path="ledger" element={<LedgerPage />} />
        <Route path="ledger/:batchId" element={<BatchHistoryPage />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route path="*" element={<p>Page not found.</p>} />
      </Route>
    </Routes>
  );
}

export default function App() {
  if (envErrors.length > 0) {
    return (
      <main className="center-card">
        <h1>Configuration needed</h1>
        <p>Copy <code>.env.example</code> to <code>.env</code> and set:</p>
        <ul>{envErrors.map((e) => <li key={e}><code>{e}</code></li>)}</ul>
      </main>
    );
  }
  return <AuthProvider><Gate /></AuthProvider>;
}
