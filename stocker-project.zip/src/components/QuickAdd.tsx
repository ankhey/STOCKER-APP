import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useCanWrite } from '../auth/AuthProvider';

export function QuickAdd() {
  const [open, setOpen] = useState(false);
  const canWrite = useCanWrite();
  const { pathname } = useLocation();
  if (!canWrite || pathname === '/receive') return null;
  return (
    <div className="fab-wrap">
      {open && (
        <div className="fab-menu" onClick={() => setOpen(false)}>
          <Link to="/receive">Receive stock</Link>
          <Link to="/products">Register product</Link>
          <Link to="/suppliers">Manage suppliers</Link>
        </div>
      )}
      <button className="fab primary" aria-label="Quick actions" aria-expanded={open} onClick={() => setOpen(!open)}>{open ? '×' : '+'}</button>
    </div>
  );
}
