export const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
export const fmtTime = (t: string | null) => (t ? t.slice(0, 5) : 'unknown');
