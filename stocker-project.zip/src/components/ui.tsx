import { ReactNode } from 'react';

export function Field({ label, error, children }: { label: string; error?: string; children: ReactNode }) {
  return (
    <label className={error ? 'field has-error' : 'field'}>
      <span>{label}</span>
      {children}
      {error && <small className="error" role="alert">{error}</small>}
    </label>
  );
}

export function PageHeader({ title, actions }: { title: string; actions?: ReactNode }) {
  return (
    <div className="page-header">
      <h1>{title}</h1>
      <div className="row">{actions}</div>
    </div>
  );
}

export function State({ loading, error, empty, emptyText, onRetry }: {
  loading: boolean; error: string | null; empty: boolean; emptyText: string; onRetry?: () => void;
}) {
  if (loading) return <p className="muted" aria-busy="true">Loading…</p>;
  if (error) return (
    <div className="banner error-banner" role="alert">
      {error} {onRetry && <button onClick={onRetry}>Retry</button>}
    </div>
  );
  if (empty) return <p className="muted">{emptyText}</p>;
  return null;
}

export function NotBuilt({ name }: { name: string }) {
  return (
    <div className="banner">
      <strong>{name}</strong> is not built yet. It is the next step of Level 1.
    </div>
  );
}
