import { useState } from 'react';
import { Link, NavLink, Outlet } from 'react-router-dom';
import { useOnline } from '../hooks/useOnline';
import { usePendingCount } from '../hooks/usePendingCount';
import { useAuth } from '../auth/AuthProvider';
import { QuickAdd } from './QuickAdd';

const NAV = [
  ['/', 'Dashboard'], ['/products', 'Products'], ['/suppliers', 'Suppliers'],
  ['/schedules', 'Supplier Schedules'], ['/receive', 'Receive Stock'],
  ['/ledger', 'Batch Ledger'], ['/settings', 'Settings']
] as const;

export function Layout() {
  const [open, setOpen] = useState(false);
  const online = useOnline();
  const pending = usePendingCount();
  const { signOut } = useAuth();
  return (
    <div className="shell">
      <header className="topbar">
        <button className="icon-btn" aria-label="Menu" aria-expanded={open} onClick={() => setOpen(!open)}>☰</button>
        <strong>Stocker</strong>
        <span className={online ? 'pill ok' : 'pill warn'} role="status">{online ? 'Online' : 'Offline'}</span>
      </header>
      <nav className={open ? 'nav open' : 'nav'} onClick={() => setOpen(false)}>
        {NAV.map(([to, label]) => (<NavLink key={to} to={to} end={to === '/'}>{label}</NavLink>))}
        <button onClick={signOut}>Sign out</button>
      </nav>
      <main className="content">
        {!online && (
          <div className="banner warn-banner" role="status">
            You are offline. Pages already loaded still open, but nothing you save is confirmed until the connection returns.
          </div>
        )}
        {pending > 0 && (
          <div className="banner warn-banner" role="status">
            {pending} delivery(ies) saved on this device only and NOT yet confirmed by the database. <Link to="/receive">Review and retry</Link>
          </div>
        )}
        <Outlet />
      </main>
      <QuickAdd />
    </div>
  );
}
