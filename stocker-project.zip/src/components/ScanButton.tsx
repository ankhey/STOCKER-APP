import { useEffect, useRef, useState } from 'react';
import { normalizeScan } from '../domain/scan';
import { ScanFailure, startScan } from '../lib/scanner';

function ScannerDialog({ onCode, onClose }: { onCode: (code: string) => void; onClose: () => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const cb = useRef(onCode);
  cb.current = onCode;
  const done = useRef(false);
  const [error, setError] = useState<string | null>(null);
  const [starting, setStarting] = useState(true);
  const [typed, setTyped] = useState('');

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    let cancelled = false;
    let stop: (() => void) | null = null;
    startScan(video, (code) => {
      if (done.current) return;
      done.current = true;
      navigator.vibrate?.(60);
      cb.current(code);
    }).then((s) => {
      if (cancelled) s(); else { stop = s; setStarting(false); }
    }).catch((e) => {
      if (cancelled) return;
      setError(e instanceof ScanFailure ? e.message : 'Could not start the camera.');
      setStarting(false);
    });
    return () => { cancelled = true; stop?.(); };
  }, []);

  function useTyped() {
    const c = normalizeScan(typed);
    if (c) { done.current = true; cb.current(c); }
  }

  return (
    <div className="scanner" role="dialog" aria-modal="true" aria-label="Scan barcode">
      <div className="scanner-box">
        <video ref={videoRef} playsInline muted className="scanner-video" />
        {!error && <div className="scanner-guide" aria-hidden="true" />}
        {starting && !error && <p className="scanner-msg">Starting camera…</p>}
        {error && <p className="scanner-msg error-banner" role="alert">{error}</p>}
        {!error && !starting && <p className="scanner-msg">Point the camera at the barcode</p>}
        <div className="row">
          <input value={typed} onChange={(e) => setTyped(e.target.value)} placeholder="Or type the code" inputMode="numeric"
            onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); useTyped(); } }} />
          <button type="button" onClick={useTyped}>Use</button>
        </div>
        <button type="button" className="primary" onClick={onClose}>Cancel</button>
      </div>
    </div>
  );
}

/** A "Scan" button that opens the camera and hands the first valid barcode to `onCode`. */
export function ScanButton({ onCode, label = 'Scan' }: { onCode: (code: string) => void; label?: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)} aria-label="Scan barcode with camera">{label}</button>
      {open && <ScannerDialog onCode={(c) => { setOpen(false); onCode(c); }} onClose={() => setOpen(false)} />}
    </>
  );
}
