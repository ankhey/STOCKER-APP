import { z } from 'zod';

const opt = (max: number) => z.string().trim().max(max).transform((v) => (v === '' ? null : v));

export const supplierSchema = z.object({
  supplier_code: z.string().trim().min(1, 'Supplier code is required').max(30),
  supplier_name: z.string().trim().min(1, 'Supplier name is required').max(150),
  contact_person: opt(100),
  phone: opt(40),
  email: z.string().trim().max(150)
    .refine((v) => v === '' || /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v), 'Enter a valid email')
    .transform((v) => (v === '' ? null : v)),
  address: opt(300),
  active: z.boolean(),
  notes: opt(1000)
});
export type SupplierFormValues = z.input<typeof supplierSchema>;

export const scheduleSchema = z.object({
  order_day_of_week: z.coerce.number().int().min(0).max(6),
  expected_delivery_day_of_week: z.coerce.number().int().min(0).max(6),
  schedule_type: z.enum(['regular', 'occasional']),
  order_cutoff_time: z.string().trim()
    .refine((v) => v === '' || /^([01]\d|2[0-3]):[0-5]\d$/.test(v), 'Use HH:MM (24-hour) or leave blank if unknown')
    .transform((v) => (v === '' ? null : v)),
  notes: opt(500),
  active: z.boolean()
});
export type ScheduleFormValues = z.input<typeof scheduleSchema>;

const dateStr = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Enter a valid date');
const optDate = z.string().refine((v) => v === '' || /^\d{4}-\d{2}-\d{2}$/.test(v), 'Enter a valid date')
  .transform((v) => (v === '' ? null : v));

export const supplierOrderSchema = z.object({
  order_date: dateStr,
  promised_delivery_date: optDate,
  actual_arrival_date: optDate,
  reference: opt(100),
  notes: opt(500)
}).superRefine((v, ctx) => {
  if (v.promised_delivery_date && v.promised_delivery_date < v.order_date)
    ctx.addIssue({ code: 'custom', path: ['promised_delivery_date'], message: 'Cannot be before the order date' });
  if (v.actual_arrival_date && v.actual_arrival_date < v.order_date)
    ctx.addIssue({ code: 'custom', path: ['actual_arrival_date'], message: 'Cannot be before the order date' });
});
export type SupplierOrderFormValues = z.input<typeof supplierOrderSchema>;
