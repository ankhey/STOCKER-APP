import { z } from 'zod';

const emptyToNull = (v: string) => (v.trim() === '' ? null : v.trim());

export const productSchema = z.object({
  internal_code: z.string().trim().regex(/^\d{6}$/, 'Internal code must be exactly 6 digits'),
  barcode: z.string().trim().max(64, 'Barcode is too long').transform(emptyToNull),
  product_name: z.string().trim().min(1, 'Product name is required').max(200),
  brand: z.string().trim().max(100).transform(emptyToNull),
  category: z.enum(['cooked', 'uncooked'], { errorMap: () => ({ message: 'Choose cooked or uncooked' }) }),
  default_storage_condition: z.enum(['chilled', 'frozen'], { errorMap: () => ({ message: 'Choose chilled or frozen' }) }),
  packet_size: z.string().trim().max(50).transform(emptyToNull),
  selling_price: z.string().trim()
    .refine((v) => v === '' || (Number.isFinite(Number(v)) && Number(v) >= 0), 'Price must be a number, 0 or more')
    .transform((v) => (v === '' ? null : Number(v))),
  default_supplier_id: z.string().transform((v) => (v === '' ? null : v)),
  active: z.boolean(),
  notes: z.string().trim().max(1000).transform(emptyToNull)
});
export type ProductFormValues = z.input<typeof productSchema>;
export type ProductParsed = z.output<typeof productSchema>;

/** Maps zod issues to { fieldName: message } for display. */
export function fieldErrors(issues: z.ZodIssue[]): Record<string, string> {
  const out: Record<string, string> = {};
  for (const i of issues) {
    const k = String(i.path[0] ?? '_');
    if (!out[k]) out[k] = i.message;
  }
  return out;
}
