export type Category = 'cooked' | 'uncooked';
export type StorageCondition = 'chilled' | 'frozen';
export type ScheduleType = 'regular' | 'occasional';
export type MemberRole = 'owner' | 'admin' | 'staff';

export interface Supplier {
  id: string; shop_id: string; supplier_code: string; supplier_name: string;
  contact_person: string | null; phone: string | null; email: string | null; address: string | null;
  active: boolean; notes: string | null; created_at: string; updated_at: string;
}
export interface SupplierSchedule {
  id: string; shop_id: string; supplier_id: string;
  order_day_of_week: number; expected_delivery_day_of_week: number;
  schedule_type: ScheduleType; order_cutoff_time: string | null; active: boolean; notes: string | null;
}
export interface SupplierOrder {
  id: string; shop_id: string; supplier_id: string; order_date: string;
  promised_delivery_date: string | null; actual_arrival_date: string | null;
  reference: string | null; notes: string | null;
}
export interface Product {
  id: string; shop_id: string; internal_code: string; barcode: string | null; product_name: string;
  brand: string | null; category: Category; default_storage_condition: StorageCondition;
  packet_size: string | null; unit_of_measure: 'packets'; selling_price: number | null;
  default_supplier_id: string | null; active: boolean; notes: string | null;
}
export interface SupplierProduct {
  id: string; shop_id: string; supplier_id: string; product_id: string;
  supplier_product_code: string | null; purchase_cost: number | null;
  min_order_quantity: number | null; lead_time_days: number | null; active: boolean; notes: string | null;
}
