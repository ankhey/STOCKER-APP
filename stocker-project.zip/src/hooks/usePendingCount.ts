import { useEffect, useState } from 'react';
import { listPending } from '../lib/idb';

/** Number of receipts stored only on this device (not yet confirmed by the database). */
export function usePendingCount(): number {
  const [n, setN] = useState(0);
  useEffect(() => {
    let alive = true;
    const refresh = () => { listPending().then((l) => alive && setN(l.length)).catch(() => undefined); };
    refresh();
    window.addEventListener('outbox-changed', refresh);
    return () => { alive = false; window.removeEventListener('outbox-changed', refresh); };
  }, []);
  return n;
}
