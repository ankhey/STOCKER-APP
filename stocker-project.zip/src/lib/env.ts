import { z } from 'zod';

const schema = z.object({
  VITE_SUPABASE_URL: z.string().url('must be a full https URL'),
  VITE_SUPABASE_ANON_KEY: z.string().min(20, 'looks too short to be a real key')
});

export function validateEnv(raw: Record<string, unknown>) {
  const r = schema.safeParse(raw);
  return r.success
    ? { env: r.data, errors: [] as string[] }
    : { env: null, errors: r.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`) };
}

export const { env, errors: envErrors } = validateEnv(import.meta.env as Record<string, unknown>);
