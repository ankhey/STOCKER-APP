import { IDBPDatabase, openDB } from 'idb';
import type { ReceiptDraft, ReceiptPayload } from '../domain/receipt';
import type { Catalog } from '../domain/catalog';

/**
 * Local-only storage. Everything here is UNCONFIRMED data that lives on this device:
 *  - drafts:   a half-filled receiving form
 *  - pending:  completed receipts waiting to be sent (outbox)
 *  - catalog:  a copy of products/supplier links so lookups work offline
 * Nothing in these stores is ever treated as saved to the cloud.
 */
export interface PendingReceipt {
  idempotencyKey: string;
  payload: ReceiptPayload;
  summary: string;
  createdAt: string;
  status: 'pending' | 'rejected';
  lastError?: string;
}

let dbp: Promise<IDBPDatabase> | null = null;
function db(): Promise<IDBPDatabase> {
  if (!dbp) {
    dbp = openDB('stocker', 1, {
      upgrade(d) {
        d.createObjectStore('drafts');
        d.createObjectStore('pending', { keyPath: 'idempotencyKey' });
        d.createObjectStore('catalog');
      }
    });
  }
  return dbp;
}
/** Closes the connection (used by tests to simulate a browser refresh). */
export async function closeDb(): Promise<void> {
  if (dbp) { (await dbp).close(); dbp = null; }
}

const notify = () => { if (typeof window !== 'undefined') window.dispatchEvent(new Event('outbox-changed')); };

export async function saveDraft(shopId: string, d: ReceiptDraft) { await (await db()).put('drafts', d, `${shopId}:receive`); }
export async function loadDraft(shopId: string): Promise<ReceiptDraft | null> {
  return ((await (await db()).get('drafts', `${shopId}:receive`)) as ReceiptDraft | undefined) ?? null;
}
export async function clearDraft(shopId: string) { await (await db()).delete('drafts', `${shopId}:receive`); }

export async function enqueue(p: PendingReceipt) { await (await db()).put('pending', p); notify(); }
export async function listPending(): Promise<PendingReceipt[]> {
  const all = (await (await db()).getAll('pending')) as PendingReceipt[];
  return all.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
}
export async function removePending(key: string) { await (await db()).delete('pending', key); notify(); }
export async function markRejected(key: string, message: string) {
  const d = await db();
  const cur = (await d.get('pending', key)) as PendingReceipt | undefined;
  if (cur) { await d.put('pending', { ...cur, status: 'rejected', lastError: message }); notify(); }
}

export async function saveCatalogCache(shopId: string, c: Omit<Catalog, 'fromCache'>) { await (await db()).put('catalog', c, shopId); }
export async function loadCatalogCache(shopId: string): Promise<Omit<Catalog, 'fromCache'> | null> {
  return ((await (await db()).get('catalog', shopId)) as Omit<Catalog, 'fromCache'> | undefined) ?? null;
}
