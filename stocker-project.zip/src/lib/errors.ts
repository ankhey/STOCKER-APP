export class AppError extends Error {
  constructor(message: string, public field?: string, public offline = false) {
    super(message);
  }
}

/** Converts Postgres / network failures into messages that never imply data was saved. */
export function toAppError(e: unknown): AppError {
  if (e instanceof AppError) return e;
  const err = e as { code?: string; message?: string; details?: string } | null;
  const message = err?.message ?? (e instanceof Error ? e.message : '');
  const text = `${message} ${err?.details ?? ''}`;
  if (/failed to fetch|networkerror|load failed|network request failed/i.test(text)) {
    return new AppError('Cannot reach the server. Nothing was saved.', undefined, true);
  }
  if (err?.code === '23505') {
    if (text.includes('internal_code')) return new AppError('This internal code is already used.', 'internal_code');
    if (text.includes('barcode')) return new AppError('This barcode is already registered.', 'barcode');
    if (text.includes('supplier_code')) return new AppError('This supplier code is already used.', 'supplier_code');
    return new AppError('A record with these details already exists.');
  }
  if (err?.code === '42501') return new AppError('You do not have permission to do that.');
  if (err?.code === '23503') return new AppError('This record is linked to other data and cannot be changed that way.');
  return new AppError(message || 'Something went wrong. Nothing was confirmed as saved.');
}
