import { createClient } from '@supabase/supabase-js';
import { env } from './env';

// When env is missing the app renders a configuration screen and never calls this client.
export const supabase = createClient(
  env?.VITE_SUPABASE_URL ?? 'http://localhost:54321',
  env?.VITE_SUPABASE_ANON_KEY ?? 'missing-anon-key-placeholder-000000',
  { auth: { persistSession: true, autoRefreshToken: true } }
);
