import { isPlausibleScan, normalizeScan } from '../domain/scan';

export type ScanErrorCode = 'insecure' | 'unsupported' | 'denied' | 'no-camera' | 'failed';
export class ScanFailure extends Error {
  constructor(public code: ScanErrorCode, message: string) { super(message); }
}

interface NativeDetector { detect(v: HTMLVideoElement): Promise<{ rawValue: string }[]> }
type DetectorCtor = new (opts?: { formats?: string[] }) => NativeDetector;
const FORMATS = ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128', 'code_39', 'itf'];

const stopStream = (s: MediaStream) => s.getTracks().forEach((t) => t.stop());

/**
 * Starts the rear camera in `video` and calls `onCode` for every plausible barcode read.
 * Uses the browser's built-in BarcodeDetector when available (Chrome on Android) and otherwise loads the
 * ZXing decoder on demand. Resolves to a function that stops the camera. Nothing leaves the device.
 */
export async function startScan(video: HTMLVideoElement, onCode: (code: string) => void): Promise<() => void> {
  if (!window.isSecureContext) throw new ScanFailure('insecure', 'The camera only works on a secure (HTTPS) page. Use the deployed app, not plain http.');
  if (!navigator.mediaDevices?.getUserMedia) throw new ScanFailure('unsupported', 'This browser cannot open the camera.');

  let stream: MediaStream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false });
  } catch (e) {
    const name = (e as DOMException).name;
    if (name === 'NotAllowedError' || name === 'SecurityError') throw new ScanFailure('denied', 'Camera permission was denied. Allow camera access for this site in the browser settings, or type the code instead.');
    if (name === 'NotFoundError' || name === 'OverconstrainedError') throw new ScanFailure('no-camera', 'No camera was found on this device.');
    throw new ScanFailure('failed', 'The camera could not be started.');
  }

  const handle = (raw: string) => {
    const code = normalizeScan(raw);
    if (code && isPlausibleScan(code)) onCode(code);
  };

  const Native = (window as unknown as { BarcodeDetector?: DetectorCtor }).BarcodeDetector;
  let detector: NativeDetector | null = null;
  if (Native) { try { detector = new Native({ formats: FORMATS }); } catch { detector = null; } }

  if (detector) {
    video.srcObject = stream;
    await video.play().catch(() => undefined);
    let alive = true;
    const det = detector;
    const tick = async () => {
      if (!alive) return;
      try { for (const r of await det.detect(video)) handle(r.rawValue); } catch { /* frame not ready */ }
      if (alive) setTimeout(tick, 200);
    };
    void tick();
    return () => { alive = false; stopStream(stream); video.srcObject = null; };
  }

  try {
    const { BrowserMultiFormatReader } = await import('@zxing/browser');
    const controls = await new BrowserMultiFormatReader().decodeFromStream(stream, video, (result) => {
      if (result) handle(result.getText());
    });
    return () => { controls.stop(); stopStream(stream); };
  } catch {
    stopStream(stream);
    throw new ScanFailure('failed', 'The scanner could not load. Check your connection once, or type the code instead.');
  }
}
