import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useCanWrite } from '../auth/AuthProvider';
import { PageHeader, State } from '../components/ui';
import { ScanButton } from '../components/ScanButton';
import { fetchLedger, LEDGER_LIMIT, setBatchSafety } from '../data/ledger';
import { listProducts } from '../data/products';
import { listSuppliers } from '../data/suppliers';
import { applyLedgerFilters, emptyFilters, LedgerFilters, LedgerRow, safetyActions, SafetyAction, STATUS_LABEL } from '../domain/ledger';
import { toAppError } from '../lib/errors';
import { useQuery } from '../hooks/useQuery';

function SafetyPanel({ row, action, onDone }: { row: LedgerRow; action: SafetyAction; onDone: (msg: string) => void }) {
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  async function go() {
    if (action.needsNote && !note.trim()) { setErr('A reason is required.'); return; }
    setBusy(true); setErr(null);
    try {
      const r = await setBatchSafety(row.batch_id, action.to, note);
      onDone(action.to === 'discarded' ? `Discarded. ${r.wasted_packets} packet(s) recorded as wastage.` : action.to === 'on_hold' ? 'Batch put on hold.' : 'Batch released.');
    } catch (e) { setErr(toAppError(e).message + ' Nothing was changed.'); } finally { setBusy(false); }
  }
  return (
    <div className="card stack" role="dialog" aria-label={`${action.label} batch`}>
      <h2>{action.label}: {row.product_name}</h2>
      <p className="muted">Batch {row.supplier_batch_number ?? '—'} · expires {row.printed_expiry_date} · {row.quantity_remaining} packets left</p>
      {action.to === 'discarded' && <p className="warn-text">This records all {row.quantity_remaining} remaining packets as wastage and cannot be undone.</p>}
      {action.to === 'on_hold' && <p className="muted">A held batch is not eligible for sale until released.</p>}
      <label className="field"><span>{action.needsNote ? 'Reason (required)' : 'Note (optional)'}</span><input value={note} onChange={(e) => setNote(e.target.value)} /></label>
      {err && <p className="error" role="alert">{err}</p>}
      <div className="row">
        <button className={action.destructive ? 'primary danger' : 'primary'} onClick={go} disabled={busy}>{busy ? 'Saving…' : `Confirm ${action.label.toLowerCase()}`}</button>
        <button onClick={() => onDone('')} disabled={busy}>Cancel</button>
      </div>
    </div>
  );
}

export function LedgerPage() {
  const canWrite = useCanWrite();
  const [panel, setPanel] = useState<{ row: LedgerRow; action: SafetyAction } | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const ledger = useQuery(fetchLedger, []);
  const suppliers = useQuery(listSuppliers, []);
  const products = useQuery(listProducts, []);
  const [f, setF] = useState<LedgerFilters>(emptyFilters);
  const set = (k: keyof LedgerFilters, v: string) => setF((p) => ({ ...p, [k]: v }));
  const [showF, setShowF] = useState(() => typeof window !== 'undefined' && window.matchMedia('(min-width: 760px)').matches);
  const activeFilters = (Object.keys(emptyFilters) as (keyof LedgerFilters)[]).filter((k) => k !== 'search' && f[k] !== emptyFilters[k]).length;
  const rows = useMemo(() => applyLedgerFilters(ledger.data ?? [], f), [ledger.data, f]);

  return <>
    <PageHeader title="Batch Ledger" actions={<button onClick={ledger.reload}>Refresh</button>} />
    {notice && <div className="banner ok-banner" role="status">{notice}</div>}
    {panel && <SafetyPanel row={panel.row} action={panel.action} onDone={(m) => { setPanel(null); if (m) { setNotice(m); ledger.reload(); } }} />}
    <div className="search-row">
      <input type="search" placeholder="Product, code, batch…" aria-label="Search batches" value={f.search} onChange={(e) => set('search', e.target.value)} />
      <ScanButton onCode={(c) => set('search', c)} />
      <button type="button" aria-expanded={showF} onClick={() => setShowF(!showF)}>Filters{activeFilters > 0 ? ` (${activeFilters})` : ''}</button>
    </div>
    {showF && <div className="filters wide">
      <select aria-label="Supplier" value={f.supplierId} onChange={(e) => set('supplierId', e.target.value)}><option value="">All suppliers</option>{(suppliers.data ?? []).map((s) => <option key={s.id} value={s.id}>{s.supplier_name}</option>)}</select>
      <select aria-label="Product" value={f.productId} onChange={(e) => set('productId', e.target.value)}><option value="">All products</option>{(products.data ?? []).map((p) => <option key={p.id} value={p.id}>{p.internal_code} {p.product_name}</option>)}</select>
      <select aria-label="Category" value={f.category} onChange={(e) => set('category', e.target.value)}><option value="">Cooked + uncooked</option><option value="cooked">Cooked</option><option value="uncooked">Uncooked</option></select>
      <select aria-label="Storage" value={f.storage} onChange={(e) => set('storage', e.target.value)}><option value="">Chilled + frozen</option><option value="chilled">Chilled</option><option value="frozen">Frozen</option></select>
      <select aria-label="Status" value={f.status} onChange={(e) => set('status', e.target.value)}>
        <option value="open">Open (stock remaining)</option><option value="all">All batches</option>
        {Object.entries(STATUS_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
      </select>
      <label className="field"><span>Expiry from</span><input type="date" value={f.expiryFrom} onChange={(e) => set('expiryFrom', e.target.value)} /></label>
      <label className="field"><span>Expiry to</span><input type="date" value={f.expiryTo} onChange={(e) => set('expiryTo', e.target.value)} /></label>
      <label className="field"><span>Delivered from</span><input type="date" value={f.deliveryFrom} onChange={(e) => set('deliveryFrom', e.target.value)} /></label>
      <label className="field"><span>Delivered to</span><input type="date" value={f.deliveryTo} onChange={(e) => set('deliveryTo', e.target.value)} /></label>
      <button onClick={() => setF(emptyFilters)}>Clear filters</button>
    </div>}
    <State loading={ledger.loading} error={ledger.error} empty={rows.length === 0}
      emptyText={ledger.data?.length ? 'No batches match these filters.' : 'No batches received yet.'} onRetry={ledger.reload} />
    {(ledger.data?.length ?? 0) >= LEDGER_LIMIT && <p className="warn-text">Showing the {LEDGER_LIMIT} earliest-expiring batches only. Narrow with filters.</p>}
    <p className="muted">"In date" only means the printed date has not passed. It does not confirm storage history or safety.</p>
    <div className="table-wrap">
      {rows.length > 0 && (
        <table className="stack-mobile">
          <thead><tr><th>Code</th><th>Product</th><th>Supplier</th><th>Cat.</th><th>Storage</th><th>Batch</th><th>Delivered</th><th>Produced</th><th>Expiry</th><th>Recv</th><th>Left</th><th>Status</th><th></th></tr></thead>
          <tbody>{rows.map((r) => (
            <tr key={r.batch_id} className={`row-${r.batch_status}`}>
              <td className="hide-sm" data-label="Code">{r.product_code}</td>
              <td className="primary" data-label="Product"><strong>{r.product_name}</strong><small className="muted block show-sm">{r.product_code} · {r.supplier_name}</small></td>
              <td className="hide-sm" data-label="Supplier">{r.supplier_name}</td>
              <td className="hide-sm" data-label="Category">{r.category}</td>
              <td data-label="Storage">{r.storage_condition}</td>
              <td data-label="Batch">{r.supplier_batch_number ?? '—'}</td>
              <td className="hide-sm" data-label="Delivered">{r.delivery_date}</td>
              <td className="hide-sm" data-label="Produced">{r.production_date ?? '—'}</td>
              <td data-label="Expiry"><span>{r.printed_expiry_date}<small className="muted block">{r.quantity_remaining > 0 ? (r.days_to_expiry < 0 ? `${-r.days_to_expiry} d past` : `${r.days_to_expiry} d left`) : ''}</small></span></td>
              <td className="hide-sm" data-label="Received">{r.quantity_received}</td>
              <td data-label="Left"><strong>{r.quantity_remaining}</strong></td>
              <td data-label="Status"><span><span className={`chip s-${r.batch_status}`}>{STATUS_LABEL[r.batch_status]}</span>{r.safety_note && <small className="muted block">{r.safety_note}</small>}</span></td>
              <td className="actions"><span className="row"><Link to={`/ledger/${r.batch_id}`}>History</Link>{canWrite && safetyActions(r).map((a) => <button key={a.to} onClick={() => { setNotice(null); setPanel({ row: r, action: a }); }}>{a.label}</button>)}</span></td>
            </tr>))}</tbody>
        </table>
      )}
    </div>
  </>;
}
