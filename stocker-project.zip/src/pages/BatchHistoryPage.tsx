import { useMemo } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useAuth } from '../auth/AuthProvider';
import { PageHeader, State } from '../components/ui';
import { loadBatchHistory } from '../data/history';
import { STATUS_LABEL } from '../domain/ledger';
import { buildTimeline, reconciles } from '../domain/history';
import { useQuery } from '../hooks/useQuery';

const fmt = (iso: string) => new Date(iso).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });

export function BatchHistoryPage() {
  const { batchId = '' } = useParams();
  const { session } = useAuth();
  const q = useQuery(() => loadBatchHistory(batchId), [batchId]);
  const timeline = useMemo(() => (q.data ? buildTimeline(q.data.movements, q.data.events) : []), [q.data]);
  const b = q.data?.batch;
  const who = (id: string | null) => (id === null ? 'Unknown' : id === session?.user.id ? 'You' : 'Another user');

  return <>
    <PageHeader title="Batch history" actions={<Link to="/ledger">← Ledger</Link>} />
    <State loading={q.loading} error={q.error} empty={false} emptyText="" onRetry={q.reload} />
    {b && <>
      <div className="card">
        <p><strong>{b.product_code} {b.product_name}</strong> <span className={`chip s-${b.batch_status}`}>{STATUS_LABEL[b.batch_status]}</span></p>
        <p className="muted">
          {b.supplier_name} · batch {b.supplier_batch_number ?? '—'} · {b.storage_condition}<br />
          Delivered {b.delivery_date}{q.data?.delivery?.delivery_note_ref && ` (ref ${q.data.delivery.delivery_note_ref})`} ·
          produced {b.production_date ?? 'not recorded'} · printed expiry <strong>{b.printed_expiry_date}</strong>
        </p>
        <p>Received <strong>{b.quantity_received}</strong> · remaining <strong>{b.quantity_remaining}</strong> packets</p>
        {b.safety_note && <p className="warn-text">Current note: {b.safety_note}</p>}
        {q.data?.delivery?.notes && <p className="muted">Delivery notes: {q.data.delivery.notes}</p>}
      </div>

      <h2>Timeline</h2>
      {timeline.length === 0 ? <p className="muted">No movements recorded for this batch.</p> : (
        <ol className="timeline">
          {timeline.map((t) => (
            <li key={t.id} className={`card ${t.kind === 'safety' ? 'tl-safety' : ''}`}>
              <div className="row between">
                <strong>{t.title}</strong>
                {t.delta !== null && <span className={t.delta > 0 ? 'delta-up' : 'delta-down'}>{t.delta > 0 ? '+' : ''}{t.delta} packets</span>}
              </div>
              <small className="muted block">{fmt(t.at)} · {who(t.by)} · balance {t.balance}</small>
              {t.detail && <p>{t.detail}</p>}
            </li>
          ))}
        </ol>
      )}
      {reconciles(timeline, b.quantity_remaining)
        ? <p className="muted" role="status">✓ The movements add up to the {b.quantity_remaining} packets shown in the ledger.</p>
        : <p className="error" role="alert">The movements do not add up to the ledger quantity. Please report this.</p>}
    </>}
  </>;
}
