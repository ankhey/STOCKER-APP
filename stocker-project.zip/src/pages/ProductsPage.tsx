import { FormEvent, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useCanWrite, useShopId } from '../auth/AuthProvider';
import { Field, PageHeader, State } from '../components/ui';
import { ScanButton } from '../components/ScanButton';
import { listProductLinks, listProducts, lookupProduct, saveProduct, suggestInternalCode } from '../data/products';
import { listSuppliers } from '../data/suppliers';
import { useQuery } from '../hooks/useQuery';
import { toAppError } from '../lib/errors';
import type { Product, Supplier } from '../types/db';
import { fieldErrors, productSchema, ProductFormValues } from '../validation/product';

const blank: ProductFormValues = {
  internal_code: '', barcode: '', product_name: '', brand: '', category: 'uncooked',
  default_storage_condition: 'chilled', packet_size: '', selling_price: '', default_supplier_id: '',
  active: true, notes: ''
};

function ProductForm({ product, suppliers, onDone, initialBarcode }: { product: Product | null; suppliers: Supplier[]; onDone: () => void; initialBarcode?: string }) {
  const shopId = useShopId();
  const links = useQuery(() => (product ? listProductLinks(product.id) : Promise.resolve([])), [product?.id]);
  const [v, setV] = useState<ProductFormValues>(product ? {
    internal_code: product.internal_code, barcode: product.barcode ?? '', product_name: product.product_name,
    brand: product.brand ?? '', category: product.category, default_storage_condition: product.default_storage_condition,
    packet_size: product.packet_size ?? '', selling_price: product.selling_price?.toString() ?? '',
    default_supplier_id: product.default_supplier_id ?? '', active: product.active, notes: product.notes ?? ''
  } : { ...blank, barcode: initialBarcode ?? '' });
  const [extra, setExtra] = useState<Set<string> | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const linked = extra ?? new Set((links.data ?? []).map((l) => l.supplier_id));
  const set = <K extends keyof ProductFormValues>(k: K, val: ProductFormValues[K]) => setV((p) => ({ ...p, [k]: val }));

  async function onScanBarcode(code: string) {
    set('barcode', code);
    setErrors((e) => { const { barcode: _drop, ...rest } = e; return rest; });
    try {
      const hit = await lookupProduct(code);
      if (hit && hit.id !== product?.id) setErrors((e) => ({ ...e, barcode: `Already registered to ${hit.internal_code} ${hit.product_name}.` }));
    } catch { /* offline: the database will still reject a duplicate on save */ }
  }

  async function suggest() {
    try { set('internal_code', await suggestInternalCode(shopId)); }
    catch (e) { setFormError(toAppError(e).message); }
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setFormError(null);
    const parsed = productSchema.safeParse(v);
    if (!parsed.success) { setErrors(fieldErrors(parsed.error.issues)); return; }
    setErrors({});
    const ids = new Set(linked);
    if (parsed.data.default_supplier_id) ids.add(parsed.data.default_supplier_id);
    setBusy(true);
    try {
      const res = await saveProduct(shopId, product?.id ?? null, parsed.data, [...ids], links.data ?? []);
      if (res.linkError) {
        setFormError(`Product saved, but supplier links failed: ${res.linkError}. Re-open the product and save again.`);
        return;
      }
      onDone();
    } catch (err) {
      const ae = toAppError(err);
      if (ae.field) setErrors({ [ae.field]: ae.message }); else setFormError(ae.message);
    } finally { setBusy(false); }
  }

  return (
    <form className="card stack" onSubmit={submit} noValidate>
      <h2>{product ? 'Edit product' : 'Register product'}</h2>
      <div className="grid2">
        <Field label="Internal code (6 digits)" error={errors.internal_code}>
          <div className="row">
            <input inputMode="numeric" maxLength={6} value={v.internal_code} onChange={(e) => set('internal_code', e.target.value)} />
            {!product && <button type="button" onClick={suggest}>Suggest</button>}
          </div>
        </Field>
        <Field label="Barcode (optional, full number)" error={errors.barcode}>
          <div className="row nowrap">
            <input inputMode="numeric" value={v.barcode} onChange={(e) => set('barcode', e.target.value)} />
            <ScanButton onCode={onScanBarcode} />
          </div>
        </Field>
      </div>
      <Field label="Product name" error={errors.product_name}>
        <input value={v.product_name} onChange={(e) => set('product_name', e.target.value)} />
      </Field>
      <div className="grid2">
        <Field label="Brand" error={errors.brand}><input value={v.brand} onChange={(e) => set('brand', e.target.value)} /></Field>
        <Field label="Packet size" error={errors.packet_size}><input value={v.packet_size} onChange={(e) => set('packet_size', e.target.value)} placeholder="e.g. 500 g" /></Field>
        <Field label="Category" error={errors.category}>
          <select value={v.category} onChange={(e) => set('category', e.target.value as 'cooked' | 'uncooked')}>
            <option value="uncooked">Uncooked</option><option value="cooked">Cooked</option>
          </select>
        </Field>
        <Field label="Default storage" error={errors.default_storage_condition}>
          <select value={v.default_storage_condition} onChange={(e) => set('default_storage_condition', e.target.value as 'chilled' | 'frozen')}>
            <option value="chilled">Chilled</option><option value="frozen">Frozen</option>
          </select>
        </Field>
        <Field label="Selling price (optional)" error={errors.selling_price}>
          <input inputMode="decimal" value={v.selling_price} onChange={(e) => set('selling_price', e.target.value)} />
        </Field>
        <Field label="Default supplier" error={errors.default_supplier_id}>
          <select value={v.default_supplier_id} onChange={(e) => set('default_supplier_id', e.target.value)}>
            <option value="">— none —</option>
            {suppliers.filter((s) => s.active || s.id === v.default_supplier_id)
              .map((s) => <option key={s.id} value={s.id}>{s.supplier_name}</option>)}
          </select>
        </Field>
      </div>
      <fieldset>
        <legend>Additional suppliers</legend>
        {suppliers.length === 0 && <p className="muted">Register suppliers first.</p>}
        {suppliers.map((s) => (
          <label key={s.id} className="check">
            <input type="checkbox" checked={linked.has(s.id) || s.id === v.default_supplier_id}
              disabled={s.id === v.default_supplier_id}
              onChange={(e) => { const n = new Set(linked); e.target.checked ? n.add(s.id) : n.delete(s.id); setExtra(n); }} />
            {s.supplier_name}{!s.active && ' (inactive)'}
          </label>
        ))}
        <p className="muted">Set cost and minimum order quantity on the supplier's page.</p>
      </fieldset>
      <label className="check"><input type="checkbox" checked={v.active} onChange={(e) => set('active', e.target.checked)} /> Active</label>
      <Field label="Notes" error={errors.notes}><textarea rows={2} value={v.notes} onChange={(e) => set('notes', e.target.value)} /></Field>
      {formError && <p className="error" role="alert">{formError}</p>}
      <div className="row">
        <button className="primary" disabled={busy || links.loading}>{busy ? 'Saving…' : 'Save product'}</button>
        <button type="button" onClick={onDone}>Cancel</button>
      </div>
    </form>
  );
}

export function ProductsPage() {
  const canWrite = useCanWrite();
  const products = useQuery(listProducts, []);
  const suppliers = useQuery(listSuppliers, []);
  const [editing, setEditing] = useState<Product | 'new' | null>(null);
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('');
  const [stor, setStor] = useState('');
  const [status, setStatus] = useState('active');
  const [params, setParams] = useSearchParams();
  const [prefill, setPrefill] = useState<string | undefined>();
  useEffect(() => {
    const b = params.get('barcode');
    if (b) { setPrefill(b); setEditing('new'); setParams({}, { replace: true }); }
  }, [params, setParams]);

  const rows = useMemo(() => {
    const s = q.trim().toLowerCase();
    return (products.data ?? []).filter((p) =>
      (!s || p.product_name.toLowerCase().includes(s) || p.internal_code.includes(s) || (p.barcode ?? '').includes(s) || (p.brand ?? '').toLowerCase().includes(s)) &&
      (!cat || p.category === cat) && (!stor || p.default_storage_condition === stor) &&
      (status === 'all' || (status === 'active') === p.active));
  }, [products.data, q, cat, stor, status]);

  const supplierName = (id: string | null) => suppliers.data?.find((s) => s.id === id)?.supplier_name ?? '—';

  if (editing && suppliers.data) {
    return <>
      <PageHeader title="Products" />
      <ProductForm product={editing === 'new' ? null : editing} suppliers={suppliers.data} initialBarcode={editing === 'new' ? prefill : undefined}
        onDone={() => { setEditing(null); setPrefill(undefined); products.reload(); }} />
    </>;
  }

  return <>
    <PageHeader title="Products" actions={canWrite && <button className="primary" onClick={() => setEditing('new')} disabled={!suppliers.data}>+ New product</button>} />
    <div className="filters">
      <div className="search-row">
        <input type="search" placeholder="Name, code, barcode…" aria-label="Search products" value={q} onChange={(e) => setQ(e.target.value)} />
        <ScanButton onCode={(c) => setQ(c)} />
      </div>
      <select value={cat} onChange={(e) => setCat(e.target.value)}><option value="">All categories</option><option value="cooked">Cooked</option><option value="uncooked">Uncooked</option></select>
      <select value={stor} onChange={(e) => setStor(e.target.value)}><option value="">Chilled + frozen</option><option value="chilled">Chilled</option><option value="frozen">Frozen</option></select>
      <select value={status} onChange={(e) => setStatus(e.target.value)}><option value="active">Active</option><option value="inactive">Inactive</option><option value="all">All</option></select>
    </div>
    <State loading={products.loading} error={products.error} empty={rows.length === 0}
      emptyText={products.data?.length ? 'No products match these filters.' : 'No products registered yet.'} onRetry={products.reload} />
    <div className="table-wrap">
      {rows.length > 0 && (
        <table className="stack-mobile">
          <thead><tr><th>Code</th><th>Name</th><th>Category</th><th>Storage</th><th>Size</th><th>Supplier</th><th></th></tr></thead>
          <tbody>
            {rows.map((p) => (
              <tr key={p.id} className={p.active ? '' : 'inactive'}>
                <td data-label="Code">{p.internal_code}</td>
                <td className="primary" data-label="Name"><strong>{p.product_name}</strong>{p.brand && <small className="muted"> · {p.brand}</small>}{p.barcode && <small className="muted block">{p.barcode}</small>}</td>
                <td data-label="Category">{p.category}</td><td data-label="Storage">{p.default_storage_condition}</td><td className="hide-sm" data-label="Size">{p.packet_size ?? '—'}</td>
                <td data-label="Supplier">{supplierName(p.default_supplier_id)}</td>
                <td className="actions">{canWrite && <button onClick={() => setEditing(p)}>Edit</button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  </>;
}
