import { FormEvent, useState } from 'react';
import { useCanWrite, useShopId } from '../auth/AuthProvider';
import { DAYS, fmtTime } from '../components/days';
import { Field, PageHeader, State } from '../components/ui';
import { listSchedules, listSupplierOrders, listSuppliers, saveSchedule, saveSupplierOrder } from '../data/suppliers';
import { useQuery } from '../hooks/useQuery';
import { toAppError } from '../lib/errors';
import type { SupplierOrder, SupplierSchedule } from '../types/db';
import { fieldErrors } from '../validation/product';
import { scheduleSchema, ScheduleFormValues, supplierOrderSchema, SupplierOrderFormValues } from '../validation/supplier';

function ScheduleForm({ supplierId, item, onDone }: { supplierId: string; item: SupplierSchedule | null; onDone: () => void }) {
  const shopId = useShopId();
  const [v, setV] = useState<ScheduleFormValues>({
    order_day_of_week: item?.order_day_of_week ?? 1, expected_delivery_day_of_week: item?.expected_delivery_day_of_week ?? 3,
    schedule_type: item?.schedule_type ?? 'regular', order_cutoff_time: item?.order_cutoff_time?.slice(0, 5) ?? '',
    notes: item?.notes ?? '', active: item?.active ?? true
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const set = <K extends keyof ScheduleFormValues>(k: K, x: ScheduleFormValues[K]) => setV((p) => ({ ...p, [k]: x }));

  async function submit(e: FormEvent) {
    e.preventDefault(); setFormError(null);
    const parsed = scheduleSchema.safeParse(v);
    if (!parsed.success) { setErrors(fieldErrors(parsed.error.issues)); return; }
    setErrors({}); setBusy(true);
    try { await saveSchedule(shopId, supplierId, item?.id ?? null, parsed.data); onDone(); }
    catch (err) { setFormError(toAppError(err).message); } finally { setBusy(false); }
  }
  const dayOpts = DAYS.map((d, i) => <option key={d} value={i}>{d}</option>);
  return (
    <form className="card stack" onSubmit={submit} noValidate>
      <h3>{item ? 'Edit schedule' : 'Add schedule'}</h3>
      <div className="grid2">
        <Field label="Order day"><select value={String(v.order_day_of_week)} onChange={(e) => set('order_day_of_week', e.target.value)}>{dayOpts}</select></Field>
        <Field label="Expected delivery day"><select value={String(v.expected_delivery_day_of_week)} onChange={(e) => set('expected_delivery_day_of_week', e.target.value)}>{dayOpts}</select></Field>
        <Field label="Type"><select value={v.schedule_type} onChange={(e) => set('schedule_type', e.target.value as 'regular' | 'occasional')}><option value="regular">Regular</option><option value="occasional">Occasional</option></select></Field>
        <Field label="Order cutoff (HH:MM, blank = unknown)" error={errors.order_cutoff_time}><input value={v.order_cutoff_time} onChange={(e) => set('order_cutoff_time', e.target.value)} placeholder="unknown" /></Field>
      </div>
      <label className="check"><input type="checkbox" checked={v.active} onChange={(e) => set('active', e.target.checked)} /> Active</label>
      <Field label="Notes" error={errors.notes}><input value={v.notes} onChange={(e) => set('notes', e.target.value)} /></Field>
      {formError && <p className="error" role="alert">{formError}</p>}
      <div className="row"><button className="primary" disabled={busy}>{busy ? 'Saving…' : 'Save'}</button><button type="button" onClick={onDone}>Cancel</button></div>
    </form>
  );
}

function OrderForm({ supplierId, item, onDone }: { supplierId: string; item: SupplierOrder | null; onDone: () => void }) {
  const shopId = useShopId();
  const [v, setV] = useState<SupplierOrderFormValues>({
    order_date: item?.order_date ?? new Date().toISOString().slice(0, 10),
    promised_delivery_date: item?.promised_delivery_date ?? '', actual_arrival_date: item?.actual_arrival_date ?? '',
    reference: item?.reference ?? '', notes: item?.notes ?? ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const set = <K extends keyof SupplierOrderFormValues>(k: K, x: SupplierOrderFormValues[K]) => setV((p) => ({ ...p, [k]: x }));

  async function submit(e: FormEvent) {
    e.preventDefault(); setFormError(null);
    const parsed = supplierOrderSchema.safeParse(v);
    if (!parsed.success) { setErrors(fieldErrors(parsed.error.issues)); return; }
    setErrors({}); setBusy(true);
    try { await saveSupplierOrder(shopId, supplierId, item?.id ?? null, parsed.data); onDone(); }
    catch (err) { setFormError(toAppError(err).message); } finally { setBusy(false); }
  }
  return (
    <form className="card stack" onSubmit={submit} noValidate>
      <h3>{item ? 'Edit order record' : 'Record an order'}</h3>
      <div className="grid2">
        <Field label="Order date" error={errors.order_date}><input type="date" value={v.order_date} onChange={(e) => set('order_date', e.target.value)} /></Field>
        <Field label="Promised delivery (if given)" error={errors.promised_delivery_date}><input type="date" value={v.promised_delivery_date} onChange={(e) => set('promised_delivery_date', e.target.value)} /></Field>
        <Field label="Actual arrival" error={errors.actual_arrival_date}><input type="date" value={v.actual_arrival_date} onChange={(e) => set('actual_arrival_date', e.target.value)} /></Field>
        <Field label="Reference" error={errors.reference}><input value={v.reference} onChange={(e) => set('reference', e.target.value)} /></Field>
      </div>
      <Field label="Notes" error={errors.notes}><input value={v.notes} onChange={(e) => set('notes', e.target.value)} /></Field>
      {formError && <p className="error" role="alert">{formError}</p>}
      <div className="row"><button className="primary" disabled={busy}>{busy ? 'Saving…' : 'Save'}</button><button type="button" onClick={onDone}>Cancel</button></div>
    </form>
  );
}

export function SchedulesPage() {
  const canWrite = useCanWrite();
  const shopId = useShopId();
  const suppliers = useQuery(listSuppliers, []);
  const [supplierId, setSupplierId] = useState('');
  const sid = supplierId || suppliers.data?.[0]?.id || '';
  const schedules = useQuery(() => (sid ? listSchedules(sid) : Promise.resolve([])), [sid]);
  const orders = useQuery(() => (sid ? listSupplierOrders(sid) : Promise.resolve([])), [sid]);
  const [editSched, setEditSched] = useState<SupplierSchedule | 'new' | null>(null);
  const [editOrder, setEditOrder] = useState<SupplierOrder | 'new' | null>(null);
  const [err, setErr] = useState<string | null>(null);

  async function toggle(s: SupplierSchedule) {
    setErr(null);
    try { await saveSchedule(shopId, s.supplier_id, s.id, { active: !s.active }); schedules.reload(); }
    catch (e) { setErr(toAppError(e).message); }
  }

  return <>
    <PageHeader title="Supplier Schedules" />
    <State loading={suppliers.loading} error={suppliers.error} empty={suppliers.data?.length === 0} emptyText="Register a supplier first." onRetry={suppliers.reload} />
    {(suppliers.data?.length ?? 0) > 0 && <>
      <select aria-label="Supplier" value={sid} onChange={(e) => { setSupplierId(e.target.value); setEditSched(null); setEditOrder(null); }}>
        {suppliers.data!.map((s) => <option key={s.id} value={s.id}>{s.supplier_name}{!s.active && ' (inactive)'}</option>)}
      </select>

      <div className="page-header"><h2>Ordering schedule</h2>{canWrite && !editSched && <button onClick={() => setEditSched('new')}>+ Add</button>}</div>
      {editSched && <ScheduleForm supplierId={sid} item={editSched === 'new' ? null : editSched} onDone={() => { setEditSched(null); schedules.reload(); }} />}
      <State loading={schedules.loading} error={schedules.error} empty={schedules.data?.length === 0} emptyText="No fixed ordering day recorded. Delivery timing is unknown; use the order log below." onRetry={schedules.reload} />
      {err && <p className="error" role="alert">{err}</p>}
      <ul className="list">{(schedules.data ?? []).map((s) => (
        <li key={s.id} className={s.active ? 'card row between' : 'card row between inactive'}>
          <span>Order <strong>{DAYS[s.order_day_of_week]}</strong> → delivery <strong>{DAYS[s.expected_delivery_day_of_week]}</strong><small className="muted block">{s.schedule_type} · cutoff {fmtTime(s.order_cutoff_time)}{s.notes ? ` · ${s.notes}` : ''}{!s.active && ' · inactive'}</small></span>
          {canWrite && <span className="row"><button onClick={() => setEditSched(s)}>Edit</button><button onClick={() => toggle(s)}>{s.active ? 'Deactivate' : 'Activate'}</button></span>}
        </li>))}</ul>

      <div className="page-header"><h2>Order log</h2>{canWrite && !editOrder && <button onClick={() => setEditOrder('new')}>+ Record order</button>}</div>
      {editOrder && <OrderForm supplierId={sid} item={editOrder === 'new' ? null : editOrder} onDone={() => { setEditOrder(null); orders.reload(); }} />}
      <State loading={orders.loading} error={orders.error} empty={orders.data?.length === 0} emptyText="No orders recorded." onRetry={orders.reload} />
      <ul className="list">{(orders.data ?? []).map((o) => (
        <li key={o.id} className="card row between">
          <span>Ordered {o.order_date}<small className="muted block">Promised: {o.promised_delivery_date ?? 'not given'} · Arrived: {o.actual_arrival_date ?? 'not yet'}{o.reference ? ` · ${o.reference}` : ''}</small></span>
          {canWrite && <button onClick={() => setEditOrder(o)}>Edit</button>}
        </li>))}</ul>
    </>}
  </>;
}
