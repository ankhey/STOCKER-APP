import { FormEvent, useState } from 'react';
import { useCanWrite, useShopId } from '../auth/AuthProvider';
import { DAYS, fmtTime } from '../components/days';
import { Field, PageHeader, State } from '../components/ui';
import { listLinksForSupplier, listSchedules, listSuppliers, saveSupplier, updateSupplierProduct } from '../data/suppliers';
import { useQuery } from '../hooks/useQuery';
import { toAppError } from '../lib/errors';
import type { Supplier } from '../types/db';
import { fieldErrors } from '../validation/product';
import { SupplierFormValues, supplierSchema } from '../validation/supplier';

function SupplierForm({ supplier, onDone }: { supplier: Supplier | null; onDone: () => void }) {
  const shopId = useShopId();
  const [v, setV] = useState<SupplierFormValues>({
    supplier_code: supplier?.supplier_code ?? '', supplier_name: supplier?.supplier_name ?? '',
    contact_person: supplier?.contact_person ?? '', phone: supplier?.phone ?? '', email: supplier?.email ?? '',
    address: supplier?.address ?? '', active: supplier?.active ?? true, notes: supplier?.notes ?? ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const set = <K extends keyof SupplierFormValues>(k: K, x: SupplierFormValues[K]) => setV((p) => ({ ...p, [k]: x }));

  async function submit(e: FormEvent) {
    e.preventDefault(); setFormError(null);
    const parsed = supplierSchema.safeParse(v);
    if (!parsed.success) { setErrors(fieldErrors(parsed.error.issues)); return; }
    setErrors({}); setBusy(true);
    try { await saveSupplier(shopId, supplier?.id ?? null, parsed.data); onDone(); }
    catch (err) {
      const ae = toAppError(err);
      if (ae.field) setErrors({ [ae.field]: ae.message }); else setFormError(ae.message);
    } finally { setBusy(false); }
  }

  return (
    <form className="card stack" onSubmit={submit} noValidate>
      <h2>{supplier ? 'Edit supplier' : 'Register supplier'}</h2>
      <div className="grid2">
        <Field label="Supplier code" error={errors.supplier_code}><input value={v.supplier_code} onChange={(e) => set('supplier_code', e.target.value)} placeholder="SUP-004" /></Field>
        <Field label="Supplier name" error={errors.supplier_name}><input value={v.supplier_name} onChange={(e) => set('supplier_name', e.target.value)} /></Field>
        <Field label="Contact person" error={errors.contact_person}><input value={v.contact_person} onChange={(e) => set('contact_person', e.target.value)} /></Field>
        <Field label="Phone" error={errors.phone}><input type="tel" value={v.phone} onChange={(e) => set('phone', e.target.value)} /></Field>
        <Field label="Email" error={errors.email}><input type="email" value={v.email} onChange={(e) => set('email', e.target.value)} /></Field>
        <Field label="Address" error={errors.address}><input value={v.address} onChange={(e) => set('address', e.target.value)} /></Field>
      </div>
      <label className="check"><input type="checkbox" checked={v.active} onChange={(e) => set('active', e.target.checked)} /> Active</label>
      <Field label="Notes" error={errors.notes}><textarea rows={2} value={v.notes} onChange={(e) => set('notes', e.target.value)} /></Field>
      {formError && <p className="error" role="alert">{formError}</p>}
      <div className="row">
        <button className="primary" disabled={busy}>{busy ? 'Saving…' : 'Save supplier'}</button>
        <button type="button" onClick={onDone}>Cancel</button>
      </div>
    </form>
  );
}

function LinkRow({ link, onSaved }: { link: Awaited<ReturnType<typeof listLinksForSupplier>>[number]; onSaved: () => void }) {
  const [cost, setCost] = useState(link.purchase_cost?.toString() ?? '');
  const [moq, setMoq] = useState(link.min_order_quantity?.toString() ?? '');
  const [code, setCode] = useState(link.supplier_product_code ?? '');
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function save() {
    const c = cost.trim() === '' ? null : Number(cost);
    const m = moq.trim() === '' ? null : Number(moq);
    if (c !== null && (!Number.isFinite(c) || c < 0)) { setErr('Cost must be 0 or more'); return; }
    if (m !== null && (!Number.isInteger(m) || m < 1)) { setErr('Min qty must be a whole number ≥ 1'); return; }
    setBusy(true); setErr(null);
    try { await updateSupplierProduct(link.id, { purchase_cost: c, min_order_quantity: m, supplier_product_code: code.trim() || null }); onSaved(); }
    catch (e) { setErr(toAppError(e).message); } finally { setBusy(false); }
  }

  return (
    <tr>
      <td className="primary" data-label="Product"><strong>{link.products?.product_name}</strong><small className="muted block">{link.products?.internal_code}</small></td>
      <td data-label="Supplier code"><input aria-label="Supplier product code" value={code} onChange={(e) => setCode(e.target.value)} /></td>
      <td data-label="Cost / packet"><input aria-label="Purchase cost" inputMode="decimal" value={cost} onChange={(e) => setCost(e.target.value)} /></td>
      <td data-label="Min qty"><input aria-label="Minimum order quantity" inputMode="numeric" value={moq} onChange={(e) => setMoq(e.target.value)} /></td>
      <td className="actions"><button onClick={save} disabled={busy}>Save</button>{err && <small className="error block">{err}</small>}</td>
    </tr>
  );
}

function SupplierDetail({ supplier, onBack, onEdit }: { supplier: Supplier; onBack: () => void; onEdit: () => void }) {
  const canWrite = useCanWrite();
  const links = useQuery(() => listLinksForSupplier(supplier.id), [supplier.id]);
  const sched = useQuery(() => listSchedules(supplier.id), [supplier.id]);
  return <>
    <PageHeader title={supplier.supplier_name} actions={<>
      <button onClick={onBack}>Back</button>{canWrite && <button onClick={onEdit}>Edit</button>}
    </>} />
    <div className="card">
      <p><strong>{supplier.supplier_code}</strong> · {supplier.active ? 'Active' : 'Inactive'}</p>
      <p className="muted">{[supplier.contact_person, supplier.phone, supplier.email, supplier.address].filter(Boolean).join(' · ') || 'No contact details recorded.'}</p>
      {supplier.notes && <p>{supplier.notes}</p>}
    </div>
    <h2>Schedules</h2>
    <State loading={sched.loading} error={sched.error} empty={sched.data?.length === 0} emptyText="No fixed schedule recorded. Manage on the Supplier Schedules page." onRetry={sched.reload} />
    <ul>{(sched.data ?? []).map((s) => (
      <li key={s.id} className={s.active ? '' : 'inactive'}>
        Order {DAYS[s.order_day_of_week]} → delivery {DAYS[s.expected_delivery_day_of_week]} ({s.schedule_type}, cutoff {fmtTime(s.order_cutoff_time)}){!s.active && ' — inactive'}
      </li>))}</ul>
    <h2>Products supplied</h2>
    <State loading={links.loading} error={links.error} empty={links.data?.length === 0} emptyText="No products linked yet. Link them from the product form." onRetry={links.reload} />
    <div className="table-wrap">
      {(links.data?.length ?? 0) > 0 && (
        <table className="stack-mobile">
          <thead><tr><th>Product</th><th>Supplier code</th><th>Cost / packet</th><th>Min qty</th><th></th></tr></thead>
          <tbody>{links.data!.map((l) => canWrite
            ? <LinkRow key={l.id} link={l} onSaved={links.reload} />
            : <tr key={l.id}><td className="primary" data-label="Product"><strong>{l.products?.product_name}</strong></td><td data-label="Supplier code">{l.supplier_product_code ?? '—'}</td><td data-label="Cost / packet">{l.purchase_cost ?? 'unknown'}</td><td data-label="Min qty">{l.min_order_quantity ?? '—'}</td><td /></tr>)}
          </tbody>
        </table>
      )}
    </div>
  </>;
}

export function SuppliersPage() {
  const canWrite = useCanWrite();
  const suppliers = useQuery(listSuppliers, []);
  const [mode, setMode] = useState<{ kind: 'list' } | { kind: 'form'; s: Supplier | null } | { kind: 'detail'; s: Supplier }>({ kind: 'list' });
  const [showInactive, setShowInactive] = useState(false);
  const [toggleError, setToggleError] = useState<string | null>(null);
  const shopId = useShopId();

  if (mode.kind === 'form') return <>
    <PageHeader title="Suppliers" />
    <SupplierForm supplier={mode.s} onDone={() => { setMode({ kind: 'list' }); suppliers.reload(); }} />
  </>;
  if (mode.kind === 'detail') return <SupplierDetail supplier={mode.s} onBack={() => setMode({ kind: 'list' })} onEdit={() => setMode({ kind: 'form', s: mode.s })} />;

  async function toggle(s: Supplier) {
    setToggleError(null);
    try {
      await saveSupplier(shopId, s.id, { active: !s.active });
      suppliers.reload();
    } catch (e) { setToggleError(toAppError(e).message); }
  }

  const rows = (suppliers.data ?? []).filter((s) => showInactive || s.active);
  return <>
    <PageHeader title="Suppliers" actions={canWrite && <button className="primary" onClick={() => setMode({ kind: 'form', s: null })}>+ New supplier</button>} />
    <label className="check"><input type="checkbox" checked={showInactive} onChange={(e) => setShowInactive(e.target.checked)} /> Show inactive</label>
    {toggleError && <p className="error" role="alert">{toggleError}</p>}
    <State loading={suppliers.loading} error={suppliers.error} empty={rows.length === 0} emptyText="No suppliers yet. Register one, or seed the three known suppliers from Settings." onRetry={suppliers.reload} />
    <ul className="list">
      {rows.map((s) => (
        <li key={s.id} className={s.active ? 'card row between' : 'card row between inactive'}>
          <button className="link" onClick={() => setMode({ kind: 'detail', s })}><strong>{s.supplier_name}</strong><small className="muted block">{s.supplier_code}{!s.active && ' · inactive'}</small></button>
          {canWrite && <div className="row"><button onClick={() => setMode({ kind: 'form', s })}>Edit</button><button onClick={() => toggle(s)}>{s.active ? 'Deactivate' : 'Activate'}</button></div>}
        </li>
      ))}
    </ul>
  </>;
}
