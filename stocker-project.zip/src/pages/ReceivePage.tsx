import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useCanWrite, useShopId } from '../auth/AuthProvider';
import { Field, PageHeader, State } from '../components/ui';
import { ScanButton } from '../components/ScanButton';
import { loadCatalog } from '../data/catalog';
import { retryPending, submitReceipt, SubmitOutcome } from '../data/receipts';
import { listSuppliers } from '../data/suppliers';
import { findProduct, isLinked } from '../domain/catalog';
import {
  buildPayload, checkHeader, checkRow, duplicateRowKeys, freshDraft, newRow, ReceiptDraft, RowInput
} from '../domain/receipt';
import { useOnline } from '../hooks/useOnline';
import { useQuery } from '../hooks/useQuery';
import { clearDraft, listPending, loadDraft, PendingReceipt, removePending, saveDraft } from '../lib/idb';
import { toAppError } from '../lib/errors';
import type { Product } from '../types/db';

function PendingPanel({ tick }: { tick: number }) {
  const [items, setItems] = useState<PendingReceipt[]>([]);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const refresh = useCallback(() => { listPending().then(setItems).catch(() => undefined); }, []);
  useEffect(() => {
    refresh();
    window.addEventListener('outbox-changed', refresh);
    return () => window.removeEventListener('outbox-changed', refresh);
  }, [refresh, tick]);
  if (items.length === 0) return null;

  async function retry() {
    setBusy(true); setMsg(null);
    try {
      const s = await retryPending();
      setMsg(`Confirmed by database: ${s.sent}. Already saved earlier (not duplicated): ${s.duplicates}. Rejected: ${s.rejected}. Still waiting: ${s.stillPending}.`);
    } catch (e) { setMsg(toAppError(e).message); } finally { setBusy(false); refresh(); }
  }
  async function discard(p: PendingReceipt) {
    if (window.confirm('Discard this unsent delivery? It was never saved to the database and will be lost.')) await removePending(p.idempotencyKey);
  }
  return (
    <section className="banner warn-banner" aria-label="Unsynchronised deliveries">
      <strong>Saved on this device only, not confirmed by the database</strong>
      <ul>{items.map((p) => (
        <li key={p.idempotencyKey}>
          {p.summary} <small className="muted">({p.status === 'rejected' ? `rejected: ${p.lastError}` : 'waiting to send'})</small>{' '}
          <button onClick={() => discard(p)}>Discard</button>
        </li>))}</ul>
      <button className="primary" onClick={retry} disabled={busy}>{busy ? 'Sending…' : 'Retry sending now'}</button>
      {msg && <p role="status">{msg}</p>}
    </section>
  );
}

function withLookup(r: RowInput, products: Product[]): RowInput {
  const prod = findProduct(products, r.code);
  if (!prod) return { ...r, productId: null };
  const storage = !r.storage || r.productId !== prod.id ? prod.default_storage_condition : r.storage;
  return { ...r, productId: prod.id, storage };
}

export function ReceivePage() {
  const shopId = useShopId();
  const canWrite = useCanWrite();
  const online = useOnline();
  const catalog = useQuery(() => loadCatalog(shopId), [shopId]);
  const suppliers = useQuery(listSuppliers, []);
  const [draft, setDraft] = useState<ReceiptDraft | null>(null);
  const [restored, setRestored] = useState(false);
  const [phase, setPhase] = useState<'edit' | 'confirm' | 'saving' | 'done'>('edit');
  const [showErrors, setShowErrors] = useState(false);
  const [outcome, setOutcome] = useState<SubmitOutcome | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let alive = true;
    loadDraft(shopId).then((d) => {
      if (!alive) return;
      if (d) { setDraft(d); setRestored(d.rows.some((r) => r.code || r.expiry || r.qty) || !!d.supplierId); } else setDraft(freshDraft());
    }).catch(() => alive && setDraft(freshDraft()));
    return () => { alive = false; };
  }, [shopId]);

  // The draft lives on this device only. It is NOT a saved delivery.
  useEffect(() => { if (draft && phase === 'edit') saveDraft(shopId, draft).catch(() => undefined); }, [draft, phase, shopId]);

  const productMap = useMemo(() => new Map((catalog.data?.products ?? []).map((p) => [p.id, p])), [catalog.data]);

  if (!canWrite) return <><PageHeader title="Receive Stock" /><p>Only the owner or an admin can receive stock.</p></>;
  if (!draft) return <><PageHeader title="Receive Stock" /><p className="muted">Loading…</p></>;

  const upd = (p: Partial<ReceiptDraft>) => setDraft((d) => (d ? { ...d, ...p } : d));
  const updRow = (key: string, p: Partial<RowInput>) =>
    setDraft((d) => (d ? { ...d, rows: d.rows.map((r) => (r.key === key ? { ...r, ...p } : r)) } : d));
  const lookup = (key: string) => {
    const products = catalog.data?.products ?? [];
    setDraft((d) => (d ? { ...d, rows: d.rows.map((r) => (r.key === key && r.code ? withLookup(r, products) : r)) } : d));
  };

  const scanRow = (key: string, code: string) => {
    const products = catalog.data?.products ?? [];
    setDraft((d) => (d ? { ...d, rows: d.rows.map((x) => (x.key === key ? withLookup({ ...x, code }, products) : x)) } : d));
  };

  const supplier = suppliers.data?.find((s) => s.id === draft.supplierId);
  const header = checkHeader(draft);
  const dups = duplicateRowKeys(draft.rows);
  const checks = draft.rows.map((r) => {
    const product = r.productId ? productMap.get(r.productId) ?? null : null;
    const supplierLinked = product && draft.supplierId && catalog.data ? isLinked(catalog.data, draft.supplierId, product.id) : null;
    const c = checkRow(r, { deliveryDate: draft.deliveryDate, product, supplierLinked });
    if (dups.has(r.key)) c.warnings.push('Another row has the same product, batch, expiry and storage. Merge them if it is the same batch.');
    return { product, ...c };
  });
  const totalPackets = draft.rows.reduce((a, r) => a + (/^\d+$/.test(r.qty) ? Number(r.qty) : 0), 0);
  const problems = header.errors.length + checks.reduce((a, c) => a + c.errors.length, 0);

  function review() {
    const products = catalog.data?.products ?? [];
    setDraft((d) => (d ? { ...d, rows: d.rows.map((r) => (r.code && !r.productId ? withLookup(r, products) : r)) } : d));
    setShowErrors(true);
    const resolved = draft!.rows.map((r) => (r.code && !r.productId ? withLookup(r, products) : r));
    const ok = header.errors.length === 0 && resolved.every((r) => {
      const product = r.productId ? productMap.get(r.productId) ?? null : null;
      return checkRow(r, { deliveryDate: draft!.deliveryDate, product, supplierLinked: null }).errors.length === 0;
    });
    if (ok) setPhase('confirm');
  }

  async function confirm() {
    setPhase('saving'); setSubmitError(null);
    try {
      const payload = buildPayload(shopId, draft!);
      const summary = `${supplier?.supplier_name ?? 'Supplier'} · ${draft!.deliveryDate} · ${draft!.rows.length} row(s) · ${totalPackets} packets`;
      const o = await submitReceipt(payload, summary);
      if (o.kind === 'rejected') { setSubmitError(o.message); setPhase('edit'); return; }
      await clearDraft(shopId).catch(() => undefined);
      setOutcome(o); setPhase('done'); setTick((t) => t + 1);
    } catch (e) {
      setSubmitError(`${toAppError(e).message} Your entries are still on screen.`); setPhase('edit');
    }
  }

  function startAnother() {
    setDraft(freshDraft()); setOutcome(null); setPhase('edit'); setShowErrors(false); setRestored(false); setSubmitError(null);
    catalog.reload();
  }

  if (phase === 'done' && outcome) {
    return <>
      <PageHeader title="Receive Stock" />
      {outcome.kind === 'confirmed' ? (
        <div className="banner ok-banner" role="status">
          <strong>Confirmed by the database.</strong>{' '}
          {outcome.result.duplicate
            ? 'This delivery had already been saved earlier; nothing was added twice.'
            : `${outcome.result.batch_ids.length} batch(es) and their receipt movements were saved together.`}
          <p><Link to="/ledger">View batch ledger</Link></p>
        </div>
      ) : outcome.kind === 'queued' ? (
        <div className="banner warn-banner" role="alert">
          <strong>NOT saved to the database yet.</strong> {outcome.reason} The delivery is stored on this device only and will not appear in the ledger or dashboard until it is sent.
        </div>
      ) : null}
      <PendingPanel tick={tick} />
      <button className="primary" onClick={startAnother}>Start another delivery</button>
    </>;
  }

  if (phase === 'confirm' || phase === 'saving') {
    const warns = checks.flatMap((c, i) => c.warnings.map((w) => `Row ${i + 1}: ${w}`)).concat(header.warnings);
    return <>
      <PageHeader title="Confirm delivery" />
      <div className="card stack">
        <p><strong>{supplier?.supplier_name}</strong> · {draft.deliveryDate}{draft.noteRef && ` · ref ${draft.noteRef}`}</p>
        <ul>{draft.rows.map((r, i) => (
          <li key={r.key}>{checks[i].product?.internal_code} {checks[i].product?.product_name}: <strong>{r.qty}</strong> packets, {r.storage}, expires <strong>{r.expiry}</strong>{r.batchNumber && `, batch ${r.batchNumber}`}</li>))}</ul>
        <p><strong>{draft.rows.length}</strong> row(s), <strong>{totalPackets}</strong> packets in total.</p>
        {warns.length > 0 && <div className="banner warn-banner"><strong>Warnings</strong><ul>{warns.map((w) => <li key={w}>{w}</li>)}</ul></div>}
        <p className="muted">{online ? 'All rows are saved together or not at all.' : 'You are offline: this will be stored on this device only and sent when you retry.'}</p>
        <div className="row">
          <button className="primary" onClick={confirm} disabled={phase === 'saving'}>{phase === 'saving' ? 'Saving…' : 'Confirm and save'}</button>
          <button onClick={() => setPhase('edit')} disabled={phase === 'saving'}>Back to edit</button>
        </div>
      </div>
    </>;
  }

  return <>
    <PageHeader title="Receive Stock" />
    <PendingPanel tick={tick} />
    {restored && <div className="banner" role="status">Restored your unsaved draft. It is stored on this device only, not in the database.</div>}
    {catalog.data?.fromCache && <div className="banner warn-banner" role="status">Using the product list saved on this device. It may be out of date.</div>}
    <State loading={catalog.loading} error={catalog.error} empty={false} emptyText="" onRetry={catalog.reload} />
    <State loading={false} error={suppliers.error} empty={false} emptyText="" onRetry={suppliers.reload} />
    {submitError && <div className="banner error-banner" role="alert"><strong>Not saved.</strong> {submitError}</div>}

    <div className="card stack">
      <div className="grid2">
        <Field label="Supplier" error={showErrors ? header.errors.find((e) => e.includes('supplier')) : undefined}>
          <select value={draft.supplierId} onChange={(e) => upd({ supplierId: e.target.value })}>
            <option value="">— choose —</option>
            {(suppliers.data ?? []).filter((s) => s.active).map((s) => <option key={s.id} value={s.id}>{s.supplier_name}</option>)}
          </select>
        </Field>
        <Field label="Delivery date" error={showErrors ? header.errors.find((e) => e.includes('date')) : undefined}>
          <input type="date" value={draft.deliveryDate} onChange={(e) => upd({ deliveryDate: e.target.value })} />
        </Field>
        <Field label="Delivery note / reference (optional)"><input value={draft.noteRef} onChange={(e) => upd({ noteRef: e.target.value })} /></Field>
        <Field label="General notes"><input value={draft.notes} onChange={(e) => upd({ notes: e.target.value })} /></Field>
      </div>
    </div>

    {draft.rows.map((r, i) => {
      const c = checks[i];
      return (
        <div className="card stack batch-row" key={r.key}>
          <div className="row between">
            <strong>Row {i + 1}</strong>
            <span className="row">
              {showErrors && <span className={c.errors.length ? 'chip s-expired' : 'chip s-in_date'}>{c.errors.length ? `${c.errors.length} to fix` : 'OK'}</span>}
              <button onClick={() => setDraft({ ...draft, rows: draft.rows.filter((x) => x.key !== r.key) })} disabled={draft.rows.length === 1}>Remove</button>
            </span>
          </div>
          <div className="grid2">
            <Field label="Product code or barcode">
              <div className="row nowrap">
                <input value={r.code} inputMode="numeric" autoComplete="off"
                  onChange={(e) => updRow(r.key, { code: e.target.value, productId: null })}
                  onBlur={() => lookup(r.key)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); lookup(r.key); } }} />
                <ScanButton onCode={(c) => scanRow(r.key, c)} />
              </div>
            </Field>
            <div className="field"><span>Product</span>
              <p className="muted">{c.product ? `${c.product.product_name} · ${c.product.category}` : r.code ? <>Not registered. <Link to={/^\d{6}$/.test(r.code) ? '/products' : `/products?barcode=${encodeURIComponent(r.code)}`}>Register it</Link></> : '—'}</p>
            </div>
          </div>
          <div className="pair">
            <Field label="Storage">
              <select value={r.storage} onChange={(e) => updRow(r.key, { storage: e.target.value as RowInput['storage'] })}>
                <option value="">— choose —</option><option value="chilled">Chilled</option><option value="frozen">Frozen</option>
              </select>
            </Field>
            <Field label="Batch / lot no."><input value={r.batchNumber} onChange={(e) => updRow(r.key, { batchNumber: e.target.value })} /></Field>
          </div>
          <div className="pair">
            <Field label="Produced (if on pack)"><input type="date" value={r.production} onChange={(e) => updRow(r.key, { production: e.target.value })} /></Field>
            <Field label="Printed expiry (label)"><input type="date" value={r.expiry} onChange={(e) => updRow(r.key, { expiry: e.target.value })} /></Field>
          </div>
          <div className="pair">
            <Field label="Quantity (packets)"><input inputMode="numeric" value={r.qty} onChange={(e) => updRow(r.key, { qty: e.target.value })} /></Field>
            <Field label="Cost / packet (opt.)"><input inputMode="decimal" value={r.cost} onChange={(e) => updRow(r.key, { cost: e.target.value })} /></Field>
          </div>
          {showErrors && c.errors.map((e) => <p key={e} className="error" role="alert">{e}</p>)}
          {c.warnings.map((w) => <p key={w} className="warn-text">⚠ {w}</p>)}
        </div>
      );
    })}

    <div className="sticky-actions">
      {showErrors && problems > 0 && <p className="error" role="alert">Fix the highlighted problems above before saving.</p>}
      <div className="row between">
        <span className="muted">{draft.rows.length} row(s) · {totalPackets} packets</span>
        <span className="row">
          <button onClick={() => upd({ rows: [...draft.rows, newRow()] })}>+ Row</button>
          <button className="primary" onClick={review} disabled={catalog.loading}>Review &amp; save</button>
        </span>
      </div>
    </div>
  </>;
}
