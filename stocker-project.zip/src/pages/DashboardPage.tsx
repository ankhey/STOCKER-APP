import { Link } from 'react-router-dom';
import { PageHeader, State } from '../components/ui';
import { loadDashboard } from '../data/dashboard';
import { STATUS_LABEL } from '../domain/ledger';
import { useOnline } from '../hooks/useOnline';
import { useQuery } from '../hooks/useQuery';

export function DashboardPage() {
  const q = useQuery(loadDashboard, []);
  const online = useOnline();
  const d = q.data;
  return <>
    <PageHeader title="Dashboard" actions={<button onClick={q.reload}>Refresh</button>} />
    <State loading={q.loading} error={q.error ? (online ? q.error : `${q.error} (offline: figures cannot be loaded)`) : null}
      empty={false} emptyText="" onRetry={q.reload} />
    {d && <>
      <div className="stats">
        <div className="card"><span className="muted">Products</span><strong>{d.productCount}</strong></div>
        <div className="card"><span className="muted">Active suppliers</span><strong>{d.activeSuppliers}</strong></div>
        <div className="card"><span className="muted">Packets recorded in stock</span><strong>{d.packetsInStock}</strong>{d.packetsExpired > 0 && <small className="warn-text">{d.packetsExpired} of them expired</small>}</div>
        <div className="card"><span className="muted">Expiring soon</span><strong>{d.expiringSoon}</strong><small className="muted">batches</small></div>
        <div className="card"><span className="muted">Expired – review</span><strong className={d.expired ? 'error' : ''}>{d.expired}</strong><small className="muted">batches</small></div>
      </div>
      {d.productCount === 0 && <p className="muted">No products yet. <Link to="/products">Register your first product.</Link></p>}
      <h2>Needs attention</h2>
      {d.attention.length === 0 ? <p className="muted">No expired or soon-to-expire batches.</p> : (
        <ul className="list">{d.attention.map((a) => (
          <li key={a.batch_id} className="card row between">
            <span>{a.product_code} {a.product_name}<small className="muted block">Expires {a.printed_expiry_date} · {a.quantity_remaining} packets</small></span>
            <span className={`chip s-${a.batch_status}`}>{STATUS_LABEL[a.batch_status]}</span>
          </li>))}</ul>
      )}
      <h2>Recent receipts</h2>
      {d.recent.length === 0 ? <p className="muted">No deliveries received yet.</p> : (
        <ul className="list">{d.recent.map((r) => (
          <li key={r.id} className="card">{r.delivery_date} · <strong>{r.supplier}</strong> · {r.batches} batch(es){r.delivery_note_ref && ` · ref ${r.delivery_note_ref}`}</li>))}</ul>
      )}
      <div className="row quick-links">
        <Link to="/receive">Receive stock</Link><Link to="/products">Register product</Link>
        <Link to="/ledger">Batch ledger</Link><Link to="/suppliers">Suppliers</Link>
      </div>
    </>}
  </>;
}
