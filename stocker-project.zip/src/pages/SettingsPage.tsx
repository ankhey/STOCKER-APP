import { useState } from 'react';
import { useAuth, useCanWrite, useShopId } from '../auth/AuthProvider';
import { PageHeader, State } from '../components/ui';
import { useQuery } from '../hooks/useQuery';
import { toAppError } from '../lib/errors';
import { supabase } from '../lib/supabase';

export function SettingsPage() {
  const shopId = useShopId();
  const canWrite = useCanWrite();
  const { session, role } = useAuth();
  const shop = useQuery(async () => {
    const { data, error } = await supabase.from('shops').select('name, timezone, expiry_warning_days').eq('id', shopId).single();
    if (error) throw toAppError(error);
    return data as { name: string; timezone: string; expiry_warning_days: number };
  }, [shopId]);
  const [tz, setTz] = useState<string | null>(null);
  const [days, setDays] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  async function saveShop() {
    setMsg(null); setErr(null);
    const timezone = (tz ?? shop.data?.timezone ?? 'UTC').trim();
    try { new Intl.DateTimeFormat('en', { timeZone: timezone }); } catch { setErr('Unknown timezone. Use a name like Region/City.'); return; }
    const d = Number(days ?? shop.data?.expiry_warning_days);
    if (!Number.isInteger(d) || d < 0 || d > 90) { setErr('Warning days must be a whole number from 0 to 90.'); return; }
    const { error } = await supabase.from('shops').update({ timezone, expiry_warning_days: d }).eq('id', shopId);
    if (error) setErr(toAppError(error).message); else { setMsg('Saved.'); shop.reload(); }
  }

  async function seed() {
    setMsg(null); setErr(null);
    const { data, error } = await supabase.rpc('seed_initial_suppliers', { p_shop_id: shopId });
    if (error) setErr(toAppError(error).message);
    else setMsg(data === 0 ? 'Nothing added: the three suppliers already exist.' : `Added ${data} supplier(s) with their known schedules. Rename them on the Suppliers page.`);
  }

  return <>
    <PageHeader title="Settings" />
    <State loading={shop.loading} error={shop.error} empty={false} emptyText="" onRetry={shop.reload} />
    {shop.data && <div className="card stack">
      <p><strong>{shop.data.name}</strong><small className="muted block">{session?.user.email} · {role}</small></p>
      <label className="field"><span>Timezone (used to decide when a batch has expired)</span>
        <input value={tz ?? shop.data.timezone} onChange={(e) => setTz(e.target.value)} disabled={!canWrite} /></label>
      <label className="field"><span>Expiry warning window (days)</span>
        <input inputMode="numeric" value={days ?? String(shop.data.expiry_warning_days)} onChange={(e) => setDays(e.target.value)} disabled={!canWrite} /></label>
      {canWrite && <div className="row"><button className="primary" onClick={saveShop}>Save settings</button><button onClick={seed}>Seed 3 starter suppliers</button></div>}
      {msg && <p role="status">{msg}</p>}
      {err && <p className="error" role="alert">{err}</p>}
    </div>}
  </>;
}
