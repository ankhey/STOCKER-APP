import { createContext, ReactNode, useCallback, useContext, useEffect, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import { toAppError } from '../lib/errors';
import type { MemberRole } from '../types/db';

interface AuthState {
  session: Session | null;
  shopId: string | null;
  role: MemberRole | null;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  signOut: () => Promise<void>;
}
const Ctx = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [shopId, setShopId] = useState<string | null>(null);
  const [role, setRole] = useState<MemberRole | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadMembership = useCallback(async (s: Session | null) => {
    if (!s) { setShopId(null); setRole(null); return; }
    const { data, error: e } = await supabase
      .from('shop_members').select('shop_id, role').eq('user_id', s.user.id).limit(1).maybeSingle();
    if (e) { setError(toAppError(e).message); return; }
    setError(null);
    setShopId(data?.shop_id ?? null);
    setRole((data?.role as MemberRole | undefined) ?? null);
  }, []);

  useEffect(() => {
    let alive = true;
    supabase.auth.getSession().then(async ({ data }) => {
      if (!alive) return;
      setSession(data.session);
      await loadMembership(data.session);
      if (alive) setLoading(false);
    }).catch((e) => { if (alive) { setError(toAppError(e).message); setLoading(false); } });
    const { data: sub } = supabase.auth.onAuthStateChange((_evt, s) => {
      setSession(s);
      void loadMembership(s);
    });
    return () => { alive = false; sub.subscription.unsubscribe(); };
  }, [loadMembership]);

  const refresh = useCallback(async () => { await loadMembership(session); }, [loadMembership, session]);
  const signOut = useCallback(async () => { await supabase.auth.signOut(); }, []);

  return <Ctx.Provider value={{ session, shopId, role, loading, error, refresh, signOut }}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthState {
  const v = useContext(Ctx);
  if (!v) throw new Error('useAuth must be used inside AuthProvider');
  return v;
}

/** For pages that are only rendered once a shop exists. */
export function useShopId(): string {
  const { shopId } = useAuth();
  if (!shopId) throw new Error('No shop loaded');
  return shopId;
}

export function useCanWrite(): boolean {
  const { role } = useAuth();
  return role === 'owner' || role === 'admin';
}
