import { FormEvent, useState } from 'react';
import { supabase } from '../lib/supabase';
import { toAppError } from '../lib/errors';
import { useAuth } from './AuthProvider';

export function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setError(null);
    const { error: err } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    if (err) setError(toAppError(err).message);
    setBusy(false);
  }

  return (
    <main className="center-card">
      <h1>Sausage Stock Manager</h1>
      <p className="muted">Sign in with the owner account created in Supabase.</p>
      <form onSubmit={submit} className="stack">
        <label>Email<input type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required /></label>
        <label>Password<input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required /></label>
        {error && <p className="error" role="alert">{error}</p>}
        <button className="primary" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
      </form>
    </main>
  );
}

export function BootstrapPage() {
  const { refresh, signOut } = useAuth();
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!name.trim()) { setError('Enter your shop name'); return; }
    setBusy(true); setError(null);
    const { error: err } = await supabase.rpc('bootstrap_shop', { p_name: name.trim() });
    if (err) setError(toAppError(err).message); else await refresh();
    setBusy(false);
  }

  return (
    <main className="center-card">
      <h1>Set up your shop</h1>
      <p className="muted">First sign-in: this account becomes the shop owner.</p>
      <form onSubmit={submit} className="stack">
        <label>Shop name<input value={name} onChange={(e) => setName(e.target.value)} required /></label>
        {error && <p className="error" role="alert">{error}</p>}
        <button className="primary" disabled={busy}>{busy ? 'Creating…' : 'Create shop'}</button>
        <button type="button" onClick={signOut}>Sign out</button>
      </form>
    </main>
  );
}
