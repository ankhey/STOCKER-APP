# Supabase migrations — Sausage Stock Manager (Level 1)

STATUS: written but NOT yet executed against a live Postgres. Apply to a fresh Supabase project and report any error.

## Apply
1. Create a Supabase project. Auth > Providers: enable Email; for a single-owner shop, disable public sign-ups after creating your account.
2. SQL Editor: run 0001 → 0006 in order (or `supabase db push` with the Supabase CLI).
3. Auth > Users > Add user (your owner email + password).
4. Sign in to the app once; first-run calls `select bootstrap_shop('Your shop name')`, which makes you owner.
5. Optional: `select seed_initial_suppliers('<shop id>');` creates the three suppliers with the known schedules.
6. Set the shop's timezone (`update shops set timezone = 'Region/City'`) — expiry status uses it. Default is UTC.

## Integrity model
- No stored stock balance. Remaining = SUM(inventory_movements) (see view `batch_ledger`).
- inventory_movements is append-only; batch balance can never go negative.
- `receive_delivery(...)` writes delivery + batches + receipt movements in ONE transaction and is idempotent on `idempotency_key` (generate one UUID per receiving form, reuse on retry).
- Printed expiry is stored as entered. The function rejects expiry < delivery date, production > expiry, qty <= 0.
- Status `expired` = printed date is before today; `eligible_for_sale` does not certify storage history.

## Client call
supabase.rpc('receive_delivery', { p_shop_id, p_idempotency_key, p_supplier_id, p_delivery_date, p_delivery_note_ref, p_notes, p_rows })
