-- Manual integrity check for receive_delivery and the ledger. NOT yet executed by the author.
-- Run in the Supabase SQL editor after the migrations. Replace the four placeholders (search for <...>):
--   <USER_UUID>  an auth user who is owner/admin of the shop
--   <SHOP_UUID>, <SUPPLIER_UUID> (active), <PRODUCT_UUID> (active)
-- Everything is rolled back at the end, so no data is kept.
begin;
select set_config('request.jwt.claims', json_build_object('sub', '<USER_UUID>', 'role', 'authenticated')::text, true);
set local role authenticated;

do $$
declare
  v_key uuid := gen_random_uuid();
  v_before int; v_after int; v_r jsonb; v_r2 jsonb; v_batch uuid; v_moves int;
  good jsonb := jsonb_build_object('product_id', '<PRODUCT_UUID>', 'printed_expiry_date', (current_date + 30)::text,
                                   'storage_condition', 'chilled', 'quantity_received', 5);
begin
  -- 1. A bad second row must roll back the whole delivery (no partial rows).
  select count(*) into v_before from inventory_batches;
  begin
    perform receive_delivery('<SHOP_UUID>', gen_random_uuid(), '<SUPPLIER_UUID>', current_date, null, null,
      jsonb_build_array(good, good || jsonb_build_object('printed_expiry_date', '')));
    raise exception 'TEST FAILED: invalid row was accepted';
  exception when others then
    if sqlerrm like 'TEST FAILED%' then raise; end if;
  end;
  select count(*) into v_after from inventory_batches;
  if v_before <> v_after then raise exception 'TEST FAILED: partial write (% -> %)', v_before, v_after; end if;
  raise notice 'PASS 1: failed multi-row receipt left nothing behind';

  -- 2. Same idempotency key twice writes once.
  v_r  := receive_delivery('<SHOP_UUID>', v_key, '<SUPPLIER_UUID>', current_date, 'DN-TEST', null, jsonb_build_array(good, good));
  v_r2 := receive_delivery('<SHOP_UUID>', v_key, '<SUPPLIER_UUID>', current_date, 'DN-TEST', null, jsonb_build_array(good, good));
  if (v_r ->> 'duplicate')::boolean or not (v_r2 ->> 'duplicate')::boolean then raise exception 'TEST FAILED: duplicate flags wrong'; end if;
  select count(*) into v_after from inventory_batches;
  if v_after <> v_before + 2 then raise exception 'TEST FAILED: retry created extra batches'; end if;
  select count(*) into v_moves from inventory_movements where batch_id in (select (jsonb_array_elements_text(v_r -> 'batch_ids'))::uuid);
  if v_moves <> 2 then raise exception 'TEST FAILED: expected 2 receipt movements, got %', v_moves; end if;
  raise notice 'PASS 2: duplicate submission wrote once, one receipt movement per batch';

  -- 3. Remaining quantity comes from movements.
  v_batch := (v_r -> 'batch_ids' ->> 0)::uuid;
  if (select quantity_remaining from batch_ledger where batch_id = v_batch) <> 5 then raise exception 'TEST FAILED: ledger remaining <> 5'; end if;
  raise notice 'PASS 3: ledger quantity_remaining = sum of movements';

  -- 4. Movements are append-only and cannot drive a batch negative.
  begin update inventory_movements set quantity_change = 99 where batch_id = v_batch; raise exception 'TEST FAILED: update allowed';
  exception when others then if sqlerrm like 'TEST FAILED%' then raise; end if; end;
  begin
    insert into inventory_movements (shop_id, product_id, batch_id, movement_type, quantity_change)
    select shop_id, product_id, id, 'sale', -999 from inventory_batches where id = v_batch;
    raise exception 'TEST FAILED: negative balance allowed';
  exception when others then if sqlerrm like 'TEST FAILED%' then raise; end if; end;
  raise notice 'PASS 4: ledger is append-only and never negative';

  -- 5. Hold needs a reason; discard writes wastage so the ledger reconciles; discarded is final.
  v_batch := (v_r -> 'batch_ids' ->> 1)::uuid;
  begin perform set_batch_safety(v_batch, 'on_hold', ''); raise exception 'TEST FAILED: hold without reason allowed';
  exception when others then if sqlerrm like 'TEST FAILED%' then raise; end if; end;
  perform set_batch_safety(v_batch, 'on_hold', 'fridge failure');
  if (select batch_status from batch_ledger where batch_id = v_batch) <> 'on_hold' then raise exception 'TEST FAILED: not on_hold'; end if;
  perform set_batch_safety(v_batch, 'discarded', 'thrown away');
  if (select quantity_remaining from batch_ledger where batch_id = v_batch) <> 0 then raise exception 'TEST FAILED: remaining not 0 after discard'; end if;
  if (select batch_status from batch_ledger where batch_id = v_batch) <> 'discarded' then raise exception 'TEST FAILED: not discarded'; end if;
  begin perform set_batch_safety(v_batch, 'ok', null); raise exception 'TEST FAILED: discarded batch changed';
  exception when others then if sqlerrm like 'TEST FAILED%' then raise; end if; end;
  if (select count(*) from batch_safety_events where batch_id = v_batch) <> 2 then raise exception 'TEST FAILED: expected 2 audit events'; end if;
  raise notice 'PASS 5: hold/discard rules, wastage movement and audit trail';
end $$;
rollback;
