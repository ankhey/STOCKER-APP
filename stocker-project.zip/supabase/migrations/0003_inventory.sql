-- 0003_inventory.sql
-- Deliveries, batches, append-only movement ledger, ledger view, atomic receipt RPC.
-- There is NO stored stock balance: remaining quantity is always SUM(inventory_movements).

create table deliveries (
  id                uuid primary key default gen_random_uuid(),
  shop_id           uuid not null,
  supplier_id       uuid not null,
  delivery_date     date not null,
  delivery_note_ref text,
  notes             text,
  idempotency_key   uuid not null,            -- generated once per receiving form; retries reuse it
  created_by        uuid default auth.uid() references auth.users(id) on delete set null,
  created_at        timestamptz not null default now(),
  foreign key (supplier_id, shop_id) references suppliers(id, shop_id),
  unique (id, shop_id),
  unique (shop_id, idempotency_key)
);
create index deliveries_recent_idx on deliveries (shop_id, delivery_date desc, created_at desc);

create table inventory_batches (
  id                       uuid primary key default gen_random_uuid(),
  shop_id                  uuid not null,
  delivery_id              uuid not null,
  product_id               uuid not null,
  supplier_id              uuid not null,
  supplier_batch_number    text,
  delivery_date            date not null,
  production_date          date,
  printed_expiry_date      date not null,     -- copied from the label; never calculated
  storage_condition        storage_condition not null,
  quantity_received        integer not null check (quantity_received > 0),
  purchase_cost_per_packet numeric(12,2) check (purchase_cost_per_packet is null or purchase_cost_per_packet >= 0),
  safety_status            batch_safety_status not null default 'ok',
  safety_note              text,
  notes                    text,
  created_by               uuid default auth.uid() references auth.users(id) on delete set null,
  created_at               timestamptz not null default now(),
  updated_at               timestamptz not null default now(),
  foreign key (delivery_id, shop_id) references deliveries(id, shop_id),
  foreign key (product_id,  shop_id) references products(id,  shop_id),
  foreign key (supplier_id, shop_id) references suppliers(id, shop_id),
  unique (id, shop_id),
  unique (id, product_id),
  check (production_date is null or production_date <= printed_expiry_date)
);
create index batches_expiry_idx   on inventory_batches (shop_id, printed_expiry_date);
create index batches_product_idx  on inventory_batches (shop_id, product_id);
create index batches_supplier_idx on inventory_batches (shop_id, supplier_id);
create index batches_delivery_idx on inventory_batches (delivery_id);
create trigger inventory_batches_updated_at before update on inventory_batches
  for each row execute function set_updated_at();

-- Quantity/identity fields are immutable after receipt so the ledger cannot silently disagree.
-- Printed expiry, storage condition, notes and safety status may still be corrected.
create function guard_batch_update() returns trigger
language plpgsql as $$
begin
  if new.quantity_received <> old.quantity_received
     or new.product_id  <> old.product_id
     or new.supplier_id <> old.supplier_id
     or new.shop_id     <> old.shop_id
     or new.delivery_id <> old.delivery_id then
    raise exception 'batch quantity and identity are immutable; use an adjustment movement'
      using errcode = '23514';
  end if;
  return new;
end $$;
create trigger inventory_batches_guard before update on inventory_batches
  for each row execute function guard_batch_update();

create table inventory_movements (
  id              uuid primary key default gen_random_uuid(),
  shop_id         uuid not null,
  product_id      uuid not null,
  batch_id        uuid not null,
  movement_type   movement_type not null,
  quantity_change integer not null,
  reference       text,
  reason          text,
  created_by      uuid default auth.uid() references auth.users(id) on delete set null,
  created_at      timestamptz not null default now(),
  foreign key (batch_id, shop_id)    references inventory_batches(id, shop_id),
  foreign key (batch_id, product_id) references inventory_batches(id, product_id),
  check (
    (movement_type in ('receipt', 'return')  and quantity_change > 0) or
    (movement_type in ('sale', 'wastage')    and quantity_change < 0) or
    (movement_type = 'adjustment'            and quantity_change <> 0)
  )
);
-- Exactly one receipt movement per batch: a retry can never double-count stock.
create unique index movements_one_receipt_per_batch on inventory_movements (batch_id)
  where movement_type = 'receipt';
create index movements_batch_idx   on inventory_movements (batch_id);
create index movements_product_idx on inventory_movements (shop_id, product_id, created_at desc);

-- Append-only ledger.
create function forbid_movement_change() returns trigger
language plpgsql as $$
begin
  raise exception 'inventory_movements is append-only; post a compensating movement instead'
    using errcode = '23514';
end $$;
create trigger movements_no_update before update or delete on inventory_movements
  for each row execute function forbid_movement_change();

-- A batch can never go below zero. Locks the batch row so concurrent sales serialise.
create function guard_batch_balance() returns trigger
language plpgsql as $$
declare v_current integer;
begin
  perform 1 from inventory_batches where id = new.batch_id for update;
  select coalesce(sum(quantity_change), 0) into v_current
  from inventory_movements where batch_id = new.batch_id;
  if v_current + new.quantity_change < 0 then
    raise exception 'movement would make batch balance negative (current %, change %)',
      v_current, new.quantity_change using errcode = '23514';
  end if;
  return new;
end $$;
create trigger movements_balance_guard before insert on inventory_movements
  for each row execute function guard_batch_balance();

-- Ledger view. Status is derived, never stored.
-- "expired" = printed expiry date is before today in the shop's timezone (the printed date itself is the last day).
-- eligible_for_sale only means "not blocked by date/hold/discard/empty"; it does NOT certify storage history.
create view batch_ledger with (security_invoker = true) as
select
  x.*,
  case
    when x.safety_status = 'discarded'            then 'discarded'
    when x.quantity_remaining <= 0                then 'depleted'
    when x.printed_expiry_date < x.today          then 'expired'
    when x.safety_status = 'on_hold'              then 'on_hold'
    when x.printed_expiry_date <= x.today + x.expiry_warning_days then 'expiring_soon'
    else 'in_date'
  end as batch_status,
  (x.safety_status = 'ok' and x.quantity_remaining > 0 and x.printed_expiry_date >= x.today) as eligible_for_sale,
  (x.printed_expiry_date - x.today) as days_to_expiry
from (
  select
    b.id as batch_id, b.shop_id, b.delivery_id,
    p.id as product_id, p.internal_code as product_code, p.barcode, p.product_name,
    p.category, b.supplier_id, s.supplier_name,
    b.storage_condition, b.supplier_batch_number,
    b.delivery_date, b.production_date, b.printed_expiry_date,
    b.quantity_received,
    coalesce(m.qty, 0)::integer as quantity_remaining,
    b.purchase_cost_per_packet, b.safety_status, b.safety_note, b.notes, b.created_at,
    (now() at time zone sh.timezone)::date as today,
    sh.expiry_warning_days
  from inventory_batches b
  join products  p  on p.id  = b.product_id
  join suppliers s  on s.id  = b.supplier_id
  join shops     sh on sh.id = b.shop_id
  left join lateral (
    select sum(mv.quantity_change) as qty from inventory_movements mv where mv.batch_id = b.id
  ) m on true
) x;

-- Atomic, idempotent stock receipt. The whole function is ONE transaction: any exception rolls back
-- the delivery, every batch and every movement. Re-calling with the same idempotency key returns the
-- original result (duplicate = true) and writes nothing.
-- p_rows: [{product_id, supplier_batch_number?, production_date?, printed_expiry_date,
--           storage_condition, quantity_received, purchase_cost_per_packet?, notes?}, ...]
create function receive_delivery(
  p_shop_id           uuid,
  p_idempotency_key   uuid,
  p_supplier_id       uuid,
  p_delivery_date     date,
  p_delivery_note_ref text,
  p_notes             text,
  p_rows              jsonb
) returns jsonb
language plpgsql security invoker set search_path = public as $$
declare
  v_delivery_id uuid;
  v_batch_id    uuid;
  v_ids         uuid[] := '{}';
  v_row         jsonb;
  v_idx         integer;
  v_product_id  uuid;
  v_expiry      date;
  v_prod        date;
  v_qty         integer;
  v_cost        numeric(12,2);
  v_storage     storage_condition;
begin
  if auth.uid() is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  if not has_shop_role(p_shop_id, array['owner', 'admin']::member_role[]) then
    raise exception 'forbidden' using errcode = '42501';
  end if;
  if p_idempotency_key is null or p_delivery_date is null then
    raise exception 'idempotency key and delivery date are required' using errcode = '22023';
  end if;
  if p_rows is null or jsonb_typeof(p_rows) <> 'array'
     or jsonb_array_length(p_rows) = 0 or jsonb_array_length(p_rows) > 200 then
    raise exception 'p_rows must be an array of 1 to 200 batch rows' using errcode = '22023';
  end if;
  perform 1 from suppliers where id = p_supplier_id and shop_id = p_shop_id and active;
  if not found then
    raise exception 'supplier not found or inactive' using errcode = '22023';
  end if;

  insert into deliveries (shop_id, supplier_id, delivery_date, delivery_note_ref, notes, idempotency_key)
  values (p_shop_id, p_supplier_id, p_delivery_date, nullif(btrim(p_delivery_note_ref), ''),
          nullif(btrim(p_notes), ''), p_idempotency_key)
  on conflict (shop_id, idempotency_key) do nothing
  returning id into v_delivery_id;

  if v_delivery_id is null then   -- same key already committed: report it, write nothing
    select id into v_delivery_id from deliveries
      where shop_id = p_shop_id and idempotency_key = p_idempotency_key;
    return jsonb_build_object(
      'duplicate', true,
      'delivery_id', v_delivery_id,
      'batch_ids', (select coalesce(jsonb_agg(id order by created_at, id), '[]'::jsonb)
                    from inventory_batches where delivery_id = v_delivery_id)
    );
  end if;

  for v_row, v_idx in
    select e.value, e.ordinality::integer from jsonb_array_elements(p_rows) with ordinality as e
  loop
    begin
      v_product_id := (v_row ->> 'product_id')::uuid;
      v_expiry     := (v_row ->> 'printed_expiry_date')::date;
      v_prod       := nullif(v_row ->> 'production_date', '')::date;
      v_qty        := (v_row ->> 'quantity_received')::integer;
      v_cost       := nullif(v_row ->> 'purchase_cost_per_packet', '')::numeric(12,2);
      v_storage    := (v_row ->> 'storage_condition')::storage_condition;
    exception when others then
      raise exception 'row %: malformed value (%)', v_idx, sqlerrm using errcode = '22023';
    end;

    if v_product_id is null then raise exception 'row %: product is required', v_idx using errcode = '22023'; end if;
    perform 1 from products where id = v_product_id and shop_id = p_shop_id and active;
    if not found then raise exception 'row %: product not found or inactive', v_idx using errcode = '22023'; end if;
    if v_expiry is null then raise exception 'row %: printed expiry date is required', v_idx using errcode = '22023'; end if;
    if v_storage is null then raise exception 'row %: storage condition is required', v_idx using errcode = '22023'; end if;
    if v_qty is null or v_qty <= 0 or v_qty > 1000000 then
      raise exception 'row %: quantity must be a whole number from 1 to 1,000,000', v_idx using errcode = '22023';
    end if;
    if v_expiry < p_delivery_date then
      raise exception 'row %: printed expiry date is before the delivery date', v_idx using errcode = '22023';
    end if;
    if v_prod is not null and (v_prod > v_expiry or v_prod > p_delivery_date) then
      raise exception 'row %: production date is after expiry or delivery date', v_idx using errcode = '22023';
    end if;

    insert into inventory_batches (
      shop_id, delivery_id, product_id, supplier_id, supplier_batch_number, delivery_date,
      production_date, printed_expiry_date, storage_condition, quantity_received,
      purchase_cost_per_packet, notes
    ) values (
      p_shop_id, v_delivery_id, v_product_id, p_supplier_id,
      nullif(btrim(v_row ->> 'supplier_batch_number'), ''), p_delivery_date,
      v_prod, v_expiry, v_storage, v_qty, v_cost, nullif(btrim(v_row ->> 'notes'), '')
    ) returning id into v_batch_id;

    insert into inventory_movements (shop_id, product_id, batch_id, movement_type, quantity_change, reference)
    values (p_shop_id, v_product_id, v_batch_id, 'receipt', v_qty,
            coalesce(nullif(btrim(p_delivery_note_ref), ''), v_delivery_id::text));

    v_ids := v_ids || v_batch_id;
  end loop;

  return jsonb_build_object('duplicate', false, 'delivery_id', v_delivery_id, 'batch_ids', to_jsonb(v_ids));
end $$;

revoke execute on function receive_delivery(uuid, uuid, uuid, date, text, text, jsonb) from public, anon;
grant  execute on function receive_delivery(uuid, uuid, uuid, date, text, text, jsonb) to authenticated;
