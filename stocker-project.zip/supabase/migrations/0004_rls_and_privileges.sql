-- 0004_rls_and_privileges.sql
-- Row-level security: members read their shop's rows; owner/admin write. No anonymous access.

alter table shops        enable row level security;
alter table shop_members enable row level security;

create policy shops_select on shops for select to authenticated using (is_shop_member(id));
create policy shops_update on shops for update to authenticated
  using (has_shop_role(id, array['owner', 'admin']::member_role[]))
  with check (has_shop_role(id, array['owner', 'admin']::member_role[]));
create policy shop_members_select on shop_members for select to authenticated
  using (user_id = auth.uid() or is_shop_member(shop_id));

do $$
declare t text;
begin
  foreach t in array array[
    'suppliers', 'supplier_schedules', 'supplier_orders', 'products', 'supplier_products',
    'deliveries', 'inventory_batches', 'inventory_movements'
  ] loop
    execute format('alter table %I enable row level security', t);
    execute format(
      'create policy %I on %I for select to authenticated using (is_shop_member(shop_id))',
      t || '_select', t);
    execute format(
      'create policy %I on %I for insert to authenticated with check (has_shop_role(shop_id, array[''owner'',''admin'']::member_role[]))',
      t || '_insert', t);
  end loop;

  -- deliveries and movements are insert-only for clients; everything else is editable.
  foreach t in array array[
    'suppliers', 'supplier_schedules', 'supplier_orders', 'products', 'supplier_products', 'inventory_batches'
  ] loop
    execute format(
      'create policy %I on %I for update to authenticated using (has_shop_role(shop_id, array[''owner'',''admin'']::member_role[])) with check (has_shop_role(shop_id, array[''owner'',''admin'']::member_role[]))',
      t || '_update', t);
  end loop;
end $$;

-- Unlinking a supplier from a product is allowed; everything else is deactivated, never deleted.
create policy supplier_products_delete on supplier_products for delete to authenticated
  using (has_shop_role(shop_id, array['owner', 'admin']::member_role[]));

-- Privileges (Supabase grants broad defaults; tighten them).
revoke all on all tables in schema public from anon;
revoke all on all sequences in schema public from anon;
revoke truncate, references, trigger on all tables in schema public from authenticated;
revoke delete on all tables in schema public from authenticated;
grant  delete on supplier_products to authenticated;
revoke insert, update on shop_members from authenticated;   -- membership changes go through definer functions
revoke insert         on shops        from authenticated;   -- shops are created via bootstrap_shop()
revoke update, delete on inventory_movements from authenticated;
revoke update, delete on deliveries          from authenticated;
