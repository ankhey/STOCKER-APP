-- 0005_seed_function.sql
-- Optional helper: creates three placeholder suppliers and their known schedules for one shop.
-- Run from the app (Settings) or SQL editor while signed in as the owner:
--   select seed_initial_suppliers('<shop uuid>');
-- Every row is editable afterwards. Names are placeholders; cutoff times are left NULL (unknown).
-- Days: 0 = Sunday ... 6 = Saturday. Safe to run twice (existing codes are skipped).

create function seed_initial_suppliers(p_shop_id uuid) returns integer
language plpgsql security invoker set search_path = public as $$
declare
  v_s1 uuid; v_s2 uuid; v_s3 uuid;
  v_new integer := 0;
begin
  if not has_shop_role(p_shop_id, array['owner', 'admin']::member_role[]) then
    raise exception 'forbidden' using errcode = '42501';
  end if;

  insert into suppliers (shop_id, supplier_code, supplier_name, notes)
  values (p_shop_id, 'SUP-001', 'Supplier 1', 'Placeholder name - rename.')
  on conflict (shop_id, supplier_code) do nothing returning id into v_s1;
  if v_s1 is not null then
    v_new := v_new + 1;
    insert into supplier_schedules (shop_id, supplier_id, order_day_of_week, expected_delivery_day_of_week, schedule_type, notes) values
      (p_shop_id, v_s1, 0, 2, 'regular',    'Sunday order -> Tuesday delivery. Cutoff time unknown.'),
      (p_shop_id, v_s1, 4, 6, 'regular',    'Thursday order -> Saturday delivery. Cutoff time unknown.'),
      (p_shop_id, v_s1, 3, 5, 'occasional', 'Wednesday order -> Friday delivery. Cutoff time unknown.');
  end if;

  insert into suppliers (shop_id, supplier_code, supplier_name, notes)
  values (p_shop_id, 'SUP-002', 'Supplier 2',
          'No fixed ordering day; ordered by stock need. Lead time variable and currently unknown. Record dates in the supplier order log.')
  on conflict (shop_id, supplier_code) do nothing returning id into v_s2;
  if v_s2 is not null then v_new := v_new + 1; end if;

  insert into suppliers (shop_id, supplier_code, supplier_name, notes)
  values (p_shop_id, 'SUP-003', 'Supplier 3', 'Placeholder name - rename.')
  on conflict (shop_id, supplier_code) do nothing returning id into v_s3;
  if v_s3 is not null then
    v_new := v_new + 1;
    insert into supplier_schedules (shop_id, supplier_id, order_day_of_week, expected_delivery_day_of_week, schedule_type, notes) values
      (p_shop_id, v_s3, 1, 3, 'regular', 'Monday order -> Wednesday delivery. Regular/occasional not specified - confirm. Cutoff unknown.'),
      (p_shop_id, v_s3, 5, 6, 'regular', 'Friday order -> Saturday delivery. Regular/occasional not specified - confirm. Cutoff unknown.');
  end if;

  return v_new;
end $$;

revoke execute on function seed_initial_suppliers(uuid) from public, anon;
grant  execute on function seed_initial_suppliers(uuid) to authenticated;
