-- 0002_catalog.sql
-- Suppliers, schedules, supplier order log, products, supplier_products.
-- Composite (id, shop_id) foreign keys make cross-shop references impossible.

create table suppliers (
  id             uuid primary key default gen_random_uuid(),
  shop_id        uuid not null references shops(id) on delete restrict,
  supplier_code  text not null check (supplier_code = btrim(supplier_code) and length(supplier_code) > 0),
  supplier_name  text not null check (length(btrim(supplier_name)) > 0),
  contact_person text,
  phone          text,
  email          text,
  address        text,
  active         boolean not null default true,
  notes          text,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (id, shop_id),
  unique (shop_id, supplier_code)
);
create trigger suppliers_updated_at before update on suppliers
  for each row execute function set_updated_at();

-- Days of week: 0 = Sunday ... 6 = Saturday. Cutoff time is NULL when unknown (never invented).
create table supplier_schedules (
  id                          uuid primary key default gen_random_uuid(),
  shop_id                     uuid not null,
  supplier_id                 uuid not null,
  order_day_of_week           smallint not null check (order_day_of_week between 0 and 6),
  expected_delivery_day_of_week smallint not null check (expected_delivery_day_of_week between 0 and 6),
  schedule_type               schedule_type not null default 'regular',
  order_cutoff_time           time,
  active                      boolean not null default true,
  notes                       text,
  created_at                  timestamptz not null default now(),
  updated_at                  timestamptz not null default now(),
  foreign key (supplier_id, shop_id) references suppliers(id, shop_id) on delete cascade
);
create index supplier_schedules_supplier_idx on supplier_schedules(supplier_id);
create trigger supplier_schedules_updated_at before update on supplier_schedules
  for each row execute function set_updated_at();

-- Manual order log: for suppliers with no fixed day / unknown lead time.
create table supplier_orders (
  id                      uuid primary key default gen_random_uuid(),
  shop_id                 uuid not null,
  supplier_id             uuid not null,
  order_date              date not null,
  promised_delivery_date  date,
  actual_arrival_date     date,
  reference               text,
  notes                   text,
  created_at              timestamptz not null default now(),
  updated_at              timestamptz not null default now(),
  foreign key (supplier_id, shop_id) references suppliers(id, shop_id) on delete cascade,
  check (promised_delivery_date is null or promised_delivery_date >= order_date),
  check (actual_arrival_date is null or actual_arrival_date >= order_date)
);
create index supplier_orders_supplier_idx on supplier_orders(supplier_id, order_date desc);
create trigger supplier_orders_updated_at before update on supplier_orders
  for each row execute function set_updated_at();

create table products (
  id                       uuid primary key default gen_random_uuid(),
  shop_id                  uuid not null references shops(id) on delete restrict,
  internal_code            text not null check (internal_code ~ '^[0-9]{6}$'),   -- text keeps leading zeros
  barcode                  text check (barcode is null or (barcode = btrim(barcode) and length(barcode) > 0)),
  product_name             text not null check (length(btrim(product_name)) > 0),
  brand                    text,
  category                 product_category not null,
  default_storage_condition storage_condition not null,
  packet_size              text,
  unit_of_measure          text not null default 'packets' check (unit_of_measure = 'packets'),
  selling_price            numeric(12,2) check (selling_price is null or selling_price >= 0),
  default_supplier_id      uuid,
  active                   boolean not null default true,
  notes                    text,
  created_at               timestamptz not null default now(),
  updated_at               timestamptz not null default now(),
  unique (id, shop_id),
  unique (shop_id, internal_code),
  unique (shop_id, barcode),        -- NULL barcodes never collide
  foreign key (default_supplier_id, shop_id) references suppliers(id, shop_id)
);
create index products_name_idx on products (shop_id, lower(product_name));
create trigger products_updated_at before update on products
  for each row execute function set_updated_at();

create table supplier_products (
  id                    uuid primary key default gen_random_uuid(),
  shop_id               uuid not null,
  supplier_id           uuid not null,
  product_id            uuid not null,
  supplier_product_code text,
  purchase_cost         numeric(12,2) check (purchase_cost is null or purchase_cost >= 0),
  min_order_quantity    integer check (min_order_quantity is null or min_order_quantity > 0),
  lead_time_days        integer check (lead_time_days is null or lead_time_days >= 0),
  active                boolean not null default true,
  notes                 text,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now(),
  foreign key (supplier_id, shop_id) references suppliers(id, shop_id) on delete cascade,
  foreign key (product_id,  shop_id) references products(id,  shop_id) on delete cascade,
  unique (supplier_id, product_id)
);
create index supplier_products_product_idx on supplier_products(product_id);
create trigger supplier_products_updated_at before update on supplier_products
  for each row execute function set_updated_at();

-- Suggests the next free six-digit code. The UNIQUE constraint remains the real guard against races.
create function next_internal_code(p_shop_id uuid) returns text
language plpgsql stable set search_path = public as $$
declare v_next integer;
begin
  select coalesce(max(internal_code::integer), 0) + 1 into v_next
  from products where shop_id = p_shop_id;
  if v_next > 999999 then
    raise exception 'internal code space exhausted';
  end if;
  return lpad(v_next::text, 6, '0');
end $$;
