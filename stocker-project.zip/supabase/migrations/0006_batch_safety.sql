-- 0006_batch_safety.sql
-- Hold / release / discard a batch, atomically, with an append-only audit trail.
-- Discarding also posts a 'wastage' movement for the remaining packets, so the ledger still reconciles.
-- Transitions: ok -> on_hold, on_hold -> ok, ok|on_hold -> discarded. Discarded is final.

create table batch_safety_events (
  id          uuid primary key default gen_random_uuid(),
  shop_id     uuid not null,
  batch_id    uuid not null,
  from_status batch_safety_status not null,
  to_status   batch_safety_status not null,
  note        text,
  created_by  uuid default auth.uid() references auth.users(id) on delete set null,
  created_at  timestamptz not null default now(),
  foreign key (batch_id, shop_id) references inventory_batches(id, shop_id)
);
create index batch_safety_events_batch_idx on batch_safety_events (batch_id, created_at desc);

create function forbid_event_change() returns trigger
language plpgsql as $$
begin
  raise exception 'batch_safety_events is append-only' using errcode = '23514';
end $$;
create trigger batch_safety_events_append_only before update or delete on batch_safety_events
  for each row execute function forbid_event_change();

alter table batch_safety_events enable row level security;
create policy batch_safety_events_select on batch_safety_events for select to authenticated
  using (is_shop_member(shop_id));
create policy batch_safety_events_insert on batch_safety_events for insert to authenticated
  with check (has_shop_role(shop_id, array['owner', 'admin']::member_role[]));
revoke all on batch_safety_events from anon;
revoke update, delete, truncate, references, trigger on batch_safety_events from authenticated;

create function set_batch_safety(p_batch_id uuid, p_status batch_safety_status, p_note text) returns jsonb
language plpgsql security invoker set search_path = public as $$
declare
  v_batch     inventory_batches%rowtype;
  v_remaining integer;
  v_note      text := nullif(btrim(p_note), '');
begin
  if auth.uid() is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  select * into v_batch from inventory_batches where id = p_batch_id for update;
  if not found then
    raise exception 'batch not found' using errcode = '22023';
  end if;
  if not has_shop_role(v_batch.shop_id, array['owner', 'admin']::member_role[]) then
    raise exception 'forbidden' using errcode = '42501';
  end if;
  if v_batch.safety_status = 'discarded' then
    raise exception 'a discarded batch cannot be changed' using errcode = '22023';
  end if;
  if p_status = v_batch.safety_status then
    raise exception 'batch is already %', p_status using errcode = '22023';
  end if;
  if p_status in ('on_hold', 'discarded') and v_note is null then
    raise exception 'a reason is required to hold or discard a batch' using errcode = '22023';
  end if;

  select coalesce(sum(quantity_change), 0) into v_remaining
  from inventory_movements where batch_id = p_batch_id;

  if p_status = 'discarded' and v_remaining > 0 then
    insert into inventory_movements (shop_id, product_id, batch_id, movement_type, quantity_change, reference, reason)
    values (v_batch.shop_id, v_batch.product_id, p_batch_id, 'wastage', -v_remaining, 'batch discarded', v_note);
  end if;

  update inventory_batches set safety_status = p_status, safety_note = v_note where id = p_batch_id;

  insert into batch_safety_events (shop_id, batch_id, from_status, to_status, note)
  values (v_batch.shop_id, p_batch_id, v_batch.safety_status, p_status, v_note);

  return jsonb_build_object('batch_id', p_batch_id, 'status', p_status,
                            'wasted_packets', case when p_status = 'discarded' then v_remaining else 0 end);
end $$;

revoke execute on function set_batch_safety(uuid, batch_safety_status, text) from public, anon;
grant  execute on function set_batch_safety(uuid, batch_safety_status, text) to authenticated;
