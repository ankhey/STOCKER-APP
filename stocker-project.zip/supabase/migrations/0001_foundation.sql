-- 0001_foundation.sql
-- Enums, tenancy (shop + members), helper functions.
-- Every business table carries shop_id so staff accounts/roles can be added later.

create type member_role         as enum ('owner', 'admin', 'staff');
create type schedule_type       as enum ('regular', 'occasional');
create type product_category    as enum ('cooked', 'uncooked');
create type storage_condition   as enum ('chilled', 'frozen');
create type movement_type       as enum ('receipt', 'sale', 'adjustment', 'return', 'wastage');
create type batch_safety_status as enum ('ok', 'on_hold', 'discarded');

create function set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

create table shops (
  id                  uuid primary key default gen_random_uuid(),
  name                text not null check (length(btrim(name)) > 0),
  timezone            text not null default 'UTC',   -- used to decide "today" for expiry; set to the shop's zone
  expiry_warning_days integer not null default 7 check (expiry_warning_days >= 0),
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);
create trigger shops_updated_at before update on shops
  for each row execute function set_updated_at();

create table shop_members (
  shop_id    uuid not null references shops(id) on delete cascade,
  user_id    uuid not null references auth.users(id) on delete cascade,
  role       member_role not null default 'staff',
  created_at timestamptz not null default now(),
  primary key (shop_id, user_id)
);
create index shop_members_user_idx on shop_members(user_id);

-- SECURITY DEFINER so RLS policies can call these without recursing into shop_members' own RLS.
create function is_shop_member(p_shop_id uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from shop_members
    where shop_id = p_shop_id and user_id = auth.uid()
  );
$$;

create function has_shop_role(p_shop_id uuid, p_roles member_role[]) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from shop_members
    where shop_id = p_shop_id and user_id = auth.uid() and role = any (p_roles)
  );
$$;

-- First-run bootstrap: the signed-in user creates their shop and becomes owner.
-- A user may only bootstrap once (single-shop v1).
create function bootstrap_shop(p_name text) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_shop_id uuid;
begin
  if auth.uid() is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  if exists (select 1 from shop_members where user_id = auth.uid()) then
    raise exception 'user already belongs to a shop' using errcode = '23505';
  end if;
  insert into shops(name) values (p_name) returning id into v_shop_id;
  insert into shop_members(shop_id, user_id, role) values (v_shop_id, auth.uid(), 'owner');
  return v_shop_id;
end $$;

revoke execute on function is_shop_member(uuid)             from public, anon;
revoke execute on function has_shop_role(uuid, member_role[]) from public, anon;
revoke execute on function bootstrap_shop(text)             from public, anon;
grant  execute on function is_shop_member(uuid)             to authenticated;
grant  execute on function has_shop_role(uuid, member_role[]) to authenticated;
grant  execute on function bootstrap_shop(text)             to authenticated;
